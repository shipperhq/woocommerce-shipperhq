<?php
class Cat extends Animal
{
}
