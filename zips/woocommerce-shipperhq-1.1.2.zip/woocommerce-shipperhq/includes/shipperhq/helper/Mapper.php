<?php
/*
Plugin Name: WooCommerce ShipperHQ
Plugin URI: http://www.shipperhq.com
Description: Woocommerce ShipperHQ Official Integration
Version: 1.0.0
Author: Karen Baker
Copyright:   Copyright (c) 2015 Zowta Ltd (http://www.WebShopApps.com)
              Copyright, 2015, Zowta, LLC - US license
*/
class ShipperHQ_Mapper
{

    /**
     * Holds the settings
     *
     * @var mixed|void
     */
    private $_settings;


    /**
     * All attributes - not currently implemented
     * @var array
     */
//    protected static $_allAttributeNames = [
//        'shipperhq_shipping_group', 'shipperhq_post_shipping_group',
//        'shipperhq_shipping_qty', 
//        'shipperhq_shipping_fee', 'shipperhq_additional_price', 'freight_class',
//        'shipperhq_nmfc_class', 'shipperhq_nmfc_sub', 'shipperhq_handling_fee', 'shipperhq_carrier_code',
//        'shipperhq_volume_weight', 'shipperhq_declared_value', 'ship_separately',
//        'shipperhq_dim_group', 'shipperhq_poss_boxes', 'ship_box_tolerance', 'must_ship_freight', 'packing_section_name',
//        'shipperhq_volume_weight',
//        'height', 'width', 'length', 'shipperhq_availability_date'
//    ];

    /**
     * Custom Product Attributes
     * @var array
     */
    protected static $_customAttributeNames = [
        'shipperhq_shipping_group', 'freight_class', 'ship_separately',
        'shipperhq_dim_group', 'must_ship_freight'
    ];

    /**
     * Woocommerce attributes (excludes height/width/length as is in meta data
     * 
     * @var array
     */
    protected static $_stdAttributeNames = [
        'height', 'width', 'length'
    ];
    

    protected static $origin = 'shipperhq_warehouse';
    protected static $location = 'shipperhq_location';

    protected static $useDefault = 'Use Default';

    /**
     * Options on the delivery type
     * @var array
     */
    protected static $shippingOptions = ['liftgate_required', 'notify_required', 'inside_delivery', 'destination_type'];


    /**
     * Woocommerce_Shipperhq_API constructor.
     */
    public function __construct()
    {
        $this->_settings      = get_option( 'woocommerce_shipperhq_settings' );
    }

    /**
     * Puts together a ShipperHQ request
     *
     * @param $package
     */
    public function create_request($package)
    {
        
        $shipperHQRequest = new \ShipperHQ\WS\Rate\Request\RateRequest();
        $shipperHQRequest->cart = $this->getCartDetails($package);
        $shipperHQRequest->destination = $this->getDestination($package);;
        $shipperHQRequest->customerDetails = $this->getCustomerGroupDetails($package);
        $shipperHQRequest->cartType = $this->getCartType($package);

//        if ($shipDetails = $this->getShipDetails($package)) {
//            $shipperHQRequest->shipDetails($package);
//        }
//        if ($carrierGroupId = $this->getCarrierGroupId($package)) {
//            $shipperHQRequest->setCarrierGroupId($package);
//        }

//        if ($carrierId = $this->getCarrierId($package)) {
//            $shipperHQRequest->setCarrierId($carrierId);
//        }
        
        $shipperHQRequest->siteDetails = ($this->getSiteDetails());
        $shipperHQRequest->credentials = ($this->getCredentials());
        return $shipperHQRequest;
        
    }
    

    /**
     * Return credentials for ShipperHQ login
     *
     * @return array
     */
    public function getCredentials()
    {
        $credentials = new \ShipperHQ\WS\Shared\Credentials();
        $credentials->apiKey = $this->_settings['api_key'];
        $credentials->password = $this->_settings['authentication_code'];
        return $credentials;
    }

    /**
     * Format cart for from shipper for Magento
     *
     * @param $request
     * @return array
     */
    public function getCartDetails($package)
    {
        $cartDetails = new \ShipperHQ\WS\Rate\Request\Checkout\Cart();
        $cartDetails->declaredValue = $package['contents_cost'];
        $cartDetails->items = $this->getFormattedItems($package['contents']);
        return $cartDetails;
    }


    /**
     * Return site specific information
     *
     * @return array
     */
    public function getSiteDetails()
    {
        $siteDetails = new \ShipperHQ\WS\Shared\SiteDetails();
        $siteDetails->ecommerceCart = "Woocommerce";
        $siteDetails->ecommerceVersion = WC()->version;
        $siteDetails->websiteUrl = get_site_url();
        $siteDetails->environmentScope = "LIVE";
        $siteDetails->appVersion = $this->plugin_name_get_version();
        return $siteDetails;
    }

    private function plugin_name_get_version() {
        $plugin_data = get_plugin_data( __FILE__ );
        $plugin_version = $plugin_data['Version'];
        return $plugin_version;
    }

   
    /**
     * Get values for items
     *
     * @param $request
     * @param $magentoItems
     * @param bool $childItems
     * @return array
     */
    private function getFormattedItems($items, $useChild = false)
    {
        $formattedItems = [];

        $counter = 0;
            
        foreach ( $items as $item_id => $product ) {
            $productData  = $product['data'];
           // $weight =	$weight + $_product->get_weight() * $values['quantity'];
            //$dimensions = $dimensions + (($_product->length * $values['quantity']) * $_product->width * $_product->height);

            $counter++;
            $warehouseDetails = $this->getWarehouseDetails($productData);
            $pickupLocationDetails = $this->getPickupLocationDetails($productData);
            // Check if product has variation. - isn't that the child item?
            if ($useChild && $productData->get_variation_id()) {
                $productA = new WC_Product($productData->get_variation_id());
            } else {
                $productA = new WC_Product($productData->id);
            }
            // Get SKU
            $sku = $productData->get_sku();

            $id = $counter;
            $productType = $productData->product_type == 'variation' && !$useChild ? "configurable" : "simple";

            $weight = $productData->get_weight();
            if(is_null($weight)) { 
                $weight = 0;
            }

            $qty = $product['quantity'] ? floatval($product['quantity']) : 0;

            $itemPrice = $productData->get_price();
            $discountedPrice = $productData->get_price(); 
            $currency = "USD";
            $formattedItem = new \ShipperHQ\WS\Rate\Request\Checkout\Item();

            $formattedItem->id = $id;
            $formattedItem->sku = $sku;
            $formattedItem->storePrice = $itemPrice;
            $formattedItem->weight = $weight;
            $formattedItem->qty = $qty;
            $formattedItem->type = $productType;
            $formattedItem->items = []; // child items
            $formattedItem->basePrice = $itemPrice;
            $formattedItem->taxInclBasePrice = $itemPrice;
            $formattedItem->taxInclStorePrice = $itemPrice;
            $formattedItem->rowTotal = $itemPrice*$qty;
            $formattedItem->baseRowTotal = $itemPrice*$qty;
            $formattedItem->discountPercent = 0; //TODO
            $formattedItem->discountedBasePrice = $discountedPrice;
            $formattedItem->discountedStorePrice = $discountedPrice;
            $formattedItem->discountedTaxInclBasePrice = $discountedPrice ;
            $formattedItem->discountedTaxInclStorePrice = $discountedPrice;
            $formattedItem->attributes = $this->populateAttributes($productData, $productA);
            $formattedItem->baseCurrency = $currency;
            $formattedItem->packageCurrency = $currency;
            $formattedItem->storeBaseCurrency = $currency;
            $formattedItem->storeCurrentCurrency = $currency;
            $formattedItem->taxPercentage = 0.00; // TODO;
            $formattedItem->freeShipping = false; // TODO
            $formattedItem->fixedPrice = false;
            $formattedItem->fixedWeight = false;
            $formattedItem->warehouseDetails            = $warehouseDetails;
            $formattedItem->pickupLocationDetails       = $pickupLocationDetails;

            if ($productData->product_type == 'variation' && !$useChild) {
                $formattedItem->setItems($this->getFormattedItems(
                    array($item_id => $product), true));
            }

            $formattedItems[] = $formattedItem;
        }
        
        return $formattedItems;
    }

    /**
     * Get values for destination
     *
     * @param $package
     * @return array
     */
    private function getDestination($package)
    {
        $destination = new \ShipperHQ\WS\Shared\Address();

        $destination->city = $package[ 'destination' ][ 'city' ];
        $destination->country = $package[ 'destination' ][ 'country' ];
        $destination->region = $package[ 'destination' ][ 'state' ];
        $destination->street = $package[ 'destination' ][ 'address' ];
        $destination->zipcode = $package[ 'destination' ][ 'postcode' ];

        return $destination;
    }

    /**
     * Reads attributes from the item
     *
     * @param $productData Holds the attributes associated with the product e.g. length, width
     * @return array
     */
    protected function populateAttributes($productData, $product)
    {
        $attributes = [];

        foreach (self::$_stdAttributeNames as $attributeName) {

            $internalAttributeName = "_".$attributeName;
            $customAttributeValue  = get_post_meta( $product->id, $internalAttributeName, true );

            if (!is_null($customAttributeValue) && !empty($customAttributeValue) &&
                !strstr($customAttributeValue, 'NONE')) {
                $attributes[] = [
                    'name' => $attributeName,
                    'value' => $customAttributeValue
                ];
            }
        }

        $this->populateMetaData($product, $attributes);


        return $attributes;
    }


    /**
     * Add values from ShipperHQ custom data
     *
     * @param $product
     */
    private function populateMetaData($product, &$attributes)
    {
        foreach (self::$_customAttributeNames as $attributeName) {
            $customAttributeValue  = get_post_meta( $product->id, $attributeName, true );
            if (!is_null($customAttributeValue) && !empty($customAttributeValue) &&
                !strstr($customAttributeValue, 'NONE')) {
                $attributes[] = [
                    'name' => $attributeName,
                    'value' => $customAttributeValue
                ];
            }

        }
    }



    protected function getWarehouseDetails($item)
    {
        return null;
    }

    protected function getPickupLocationDetails($item)
    {
        return null;
    }

    protected function getDefaultWarehouseStockDetail($item)
    {
        return null;
    }

    /**
     * Gets the magento order number
     * @param $order
     * @return mixed
     */
    protected function getMagentoOrderNumber($order)
    {
        return null;
    }

    /*
    * Return customer group details
    * TODO
    */
    public function getCustomerGroupDetails($request)
    {
        return null;
    }

    /*
    * Return ship Details selected
     * TODO - Pickup
    *
    */
    public function getShipDetails($request)
    {
        return null;
    }

    /*
    * Return cartType String
    *
    */
    public function getCartType($request)
    {
        return "checkout";
    }

    /*
    * Return Delivery Date selected
    *
    */
    public function getDeliveryDateUTC($request)
    {
        return null;
    }

    public function getDeliveryDate($request)
    {
        return null;
    }

    /*
    * Return pickup location selected
    *
    */
    public function getLocation($request)
    {
        return null;

    }

    /*
     * Return selected carrierGroup id
     */
    public function getCarrierGroupId($request)
    {
        return null;

    }

    /*
   * Return selected carrier id
   *
   */
    public function getCarrierId($request)
    {
        return null;

    }



}