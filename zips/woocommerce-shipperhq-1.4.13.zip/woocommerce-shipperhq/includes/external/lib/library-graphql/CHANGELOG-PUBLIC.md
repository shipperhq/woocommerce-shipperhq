# Change Log


## 20.0.0 (2019-07-30)
Initial Release


## 20.0.1 (2019-08-30)
SHQ18-2402/SHQ18-2431 implement improvements to Listing API


## 20.0.2 (2019-10-02)
SHQ18-2560 Updated for use with WooCommerce


## 20.0.3 (2019-12-03)
TGR-66 add recipient to placeOrder request


## 20.0.4 (2019-12-03)
TGR-66 add recipient to placeOrder request

## 20.0.5 (2019-12-18)
SHQ18-3003 support for GROUPED product types


## 20.1.0 (2021-02-02)
MNB-669 fixes errors and adds getFinalShippingChosen query


## 20.2.0 (2021-03-29)
RIV-443 add placeOrder query


## 20.3.0 (2022-02-02)
RIV-443 update get methods for serializer


## 20.3.0 (2022-02-03)
RIV-898 Adds missing coupon code field


## 20.4.0 (2022-05-13)
MND-2430 M2.4.4 compatibility


## 20.4.1 (2022-05-25)
MNB-2542 Change version requirements for laminas-dependency-plugin


## 20.4.2 (2022-06-01)
MNB-2576 Rolled back MNB-2405


## 20.4.3 (2022-06-20)
MNB-2405 added RMSItem.name field


