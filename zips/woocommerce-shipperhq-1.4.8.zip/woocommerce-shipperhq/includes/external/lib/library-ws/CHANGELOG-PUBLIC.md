## 20.4.0 (2018-06-21)
Bring releases and versioning back in line


## 20.4.1 (2019-03-27)
SHQ18-1712 Dont send empty request to ShipperHQ


## 20.5.0 (2021-03-30)
RIV-443 Add placeorder support


