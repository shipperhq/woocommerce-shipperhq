=== ShipperHQ for WooCommerce ===
Contributors: shipperhq
Tags: ecommerce, e-commerce, store, sales, sell, shipping, shipping rates, rating, rate management, cart, checkout, downloadable, downloads, shipperhq, shipper hq
Requires at least: 4.4
Tested up to: 5.5
Stable tag: 1.4.8
Requires PHP: 5.6
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Control the shipping rates and options you show in your WooCommerce cart. Live rates from 30+ carriers, LTL Freight and custom rates.

==Description==

ShipperHQ helps ecommerce merchants align the checkout experience on their website to their own unique products and customers. Live shipping rates from 50+ small package, international and LTL freight carriers available.

== Deliver on Customer Expectations with Your Shipping==

ShipperHQ is a shipping plugin that helps ecommerce merchants take control of the checkout experience on their WooCommerce website. With our tools, you can easily tailor the shipping rates and options that appear to the exact buying scenario that's happening, taking into account information like what products are being purchased, where a customer is located and how much they are spending. Because we integrate with 50+ small package and LTL freight carriers, you can get live-rates every time and provide your customers with the most accurate shipping prices possible.

[youtube https://www.youtube.com/watch?v=2WymQcG1ofE]

== 30 Day Risk Free Trial ==
ShipperHQ comes with a [30 Day Risk Free Trial](https://shipperhq.com/signup?utm_source=woocommerce-marketplace&utm_medium=app-listing&utm_campaign=woocommerce-marketplace) and subscriptions starting [as low as $50 a month](https://shipperhq.com/pricing).

== Create a shipping strategy that works for you==
Customize the shipping rates and delivery options that appear once a customer is ready to buy. Whatever the goal is, from increasing conversions, breaking even on shipping or generating a profit from it, ShipperHQ’s shipping platform makes it easy to configure these needs long term or make changes instantaneously.


= Streamline all your shipping options =
Easily manage all your shipping options and logistics providers in one place, including major providers like UPS, USPS, FedEx and DHL. Present customers with only the most optimized delivery choices possible at checkout, including fast, innovative and convenient services like in-store pickup, alternate pickup and same-day delivery.

= Take on Amazon with accurate delivery dates =
Instantly pull delivery dates straight from your carrier of choice, including FedEx, UPS, USPS, and Canada Post. Factor information such as days or holidays you don’t ship or fulfill orders by setting blackout dates, cutoff times and shipping lead times for products, origins, carriers and more.
= Create shipping rules based on real-world logic =
Configure personalized shipping rules, discounts, promotions and surcharges that affect rates and delivery options across the board, for a certain time range or for a given checkout scenario. Tailor the information that appears at checkout by considering what a customer is buying, where they are located, how much they’re spending and more.
= Improve shipping margins through automation =
Manage shipping rates from multiple origins, including warehouse and dropship vendors. Prevent shipping overcharges and undercharges by defining how products are packed together and automating how packages are selected for orders. Plus, determine if a customer’s address type so you get charged the correct last mile delivery fees every time.

= Supports over 50 carriers including =
UPS (Small Package, LTL Freight, Ground with Freight Pricing, UPS Access Point), FedEx (Small Package, LTL Freight, SmartPost, Hold at Location, SameDay City), Kuehne+Nagel LTL eCommerce, USPS, DHL(Express, eCommerce), uShip, Zenda, DHL Express via ILS, FlavorCloud, Cerasis, Purolator, Australia Post (Retail, eParcel), Canada Post, YRC Freight, GLS/GSO and Fastway


== A Reliable Partner for Your Ecommerce Shipping Strategy ==

= Easy-to-Use Dashboard =
With all the options available for managing shipping rates, it would be easy for things to get a bit complex. That's why the ShipperHQ dashboard was developed specifically to manage shipping. Instead of managing shipping from the Wordpress admin panel, you'll be able to manage your shipping in a purpose-built dashboard. The right tool for the right job.

= Painless Commerce Platform Integration =
With ShipperHQ configuration management, carrier setup, and rate calculation logic all happen in the cloud. By installing a single plugin you can connect your WooCommerce store with the advanced capabilities in your ShipperHQ account.

= Broad Carrier Support =
ShipperHQ has built-in support for UPS, FedEx, USPS, and other major carriers. Use base rates or enter your account details to use your negotiated rates. Either way, you can rest easy knowing that the work of managing connections to your carriers of choice is handled by ShipperHQ. The world's most powerful shipping rate interface backed by a worldwide fleet of elite carriers, we feel like this makes for a winning combination.

= Work with our Shipping Experts =
ShipperHQ was built on the culmination of many years of shipping experience and we have serviced tens of thousands of merchants worldwide. Our team of ecommerce shipping experts are happy to help you get up and running in no time. With Consultation Services, Priority Support, and Configuration Services you have the option to work with us through set up or to leave the shipping to us so you can focus on running your business. Contact us for a quote on any of our additional services.

== Installation ==

Our [Help Docs](http://docs.shipperhq.com) provide detailed instructions on [how to install the ShipperHQ WooCommerce Plugin](https://docs.shipperhq.com/install-woocommerce-plugin) and more!


== Frequently Asked Questions ==

= What happens after 30 days? =
If you haven't set up billing during your 30 day trial period, your account will be deactivated. However, you will still have the ability to log in and set up billing to re-enable your account. Your settings will be saved for at least 30 days if you wish to re-activate. After 30 days of inactivity your account may be deleted.

= How long are your contracts? =
When signing up for a ShipperHQ plan, you are given the option to pay monthly or annually. On our Essentials, Standard and Pro plans, you have the option to cancel at any time. However, we do not provide a refund if you decide to cancel before your next auto-renewal period. If you are an Enterprise user, contracts are written on an individual basis.


== Screenshots ==

1. ShipperHQ at work in your WooCommerce Cart.
2. ShipperHQ at work in your WooCommerce Checkout.
3. Origins in ShipperHQ
4. Carriers in ShipperHQ
5. Carriers Rules in ShipperHQ
6. Zones in ShipperHQ
7. Shipping Groups in ShipperHQ
8. Filters in ShipperHQ

== Changelog ==

= 1.4.6 - 2021-07-26
MNB-1477 Display shipping origin in order details
= 1.4.5 - 2020-12-04
MNB-890 Update marketing copy
= 1.4.4 - 2020-10-29
MNB-567 Correct tooltips on product listing admin
= 1.4.3 - 2019-12-10
SHQ18-2977 Updated to work with new library-shipper
= 1.4.2 - 2019-12-05
SHQ18-2977 Fixed error when order does not have a shipping line
= 1.4.1 - 2019-10-02
SHQ18-2560 Updated lib-GraphQL for use with WooCommerce
= 1.4.0 - 2019-09-23
SHQ18-2560/SHQ18-2561 Add uShip Listing Feature
= 1.3.8 - 2019-05-31
SHQ18-2022 Added hs code to shipping attributes
= 1.3.7 - 2019-05-14
Maintenance release
= 1.3.6 - 2019-01-25
SHQ18-1204 Make methods around getting inventory status public so they can be extended
= 1.3.5 - 2018-12-05
SHQ18-1158 Prevent calling ShipperHQ API when credentials are missing
= 1.3.4 - 2018-11-27
SHQ18-1079 Support for WooCommerce product add on module
= 1.3.3 - 2018-10-31
SHQ18-1006 Fix issue with ship separately and must ship freight checlboxes
= 1.2.11 - 2017-10-11
SHQ16-2339 remove use of deprecated function
= 1.2.10 - 2017-10-09
Update to readme.txt for WordPress store release
= 1.2.9 - 2017-08-15
SHQ16-2216 modified headers and function name after review
= 1.2.8 - 2017-08-09
SHQ16-2202 Support for 2.6 and below version no parent_id


[See CHANGELOG-PUBLIC.md for all versions](https://plugins.svn.wordpress.org/woo-shipperhq/trunk/CHANGELOG-PUBLIC.md)

== Upgrade Notice ==

= 1.4.3 =
Update to this version to fix issues with virtual products
= 1.3.5 =
Update to this version to prevent calls to ShipperHQ API unnecessarily
= 1.3.3 =
Update to this version to ensure must ship freight and ship separately checkboxes work
= 1.2.11 =
Update to this version to ensure compatibility with WooCommerce v3.0+
= 1.2.10 =
This version includes changes to the listing text
= 1.2.9 =
This version was submitted to WordPress for public release
