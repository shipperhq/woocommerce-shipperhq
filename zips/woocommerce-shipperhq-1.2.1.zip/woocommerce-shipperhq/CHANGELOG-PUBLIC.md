# Change Log -- DO NOT MANUALLY CHANGE
1.0.1 Initial Release

1.0.2 SHQ16-1355 Implemented merged rate support

1.0.3 Improving Build process

1.1.0 Improving Build process

1.1.1 Support for shipping attributes on product variants

1.1.2 SHQ16-1841 WooCommerce build changes

