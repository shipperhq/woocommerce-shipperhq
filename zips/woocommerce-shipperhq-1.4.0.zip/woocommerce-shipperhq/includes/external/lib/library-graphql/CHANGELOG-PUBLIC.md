# Change Log


## 20.0.0 (2019-07-30)
Initial Release


## 20.0.1 (2019-08-30)
SHQ18-2402/SHQ18-2431 implement improvements to Listing API


