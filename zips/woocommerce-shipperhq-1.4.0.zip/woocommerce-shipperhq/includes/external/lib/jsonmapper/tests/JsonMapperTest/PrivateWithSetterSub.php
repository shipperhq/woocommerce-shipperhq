<?php
class PrivateWithSetterSub extends PrivateWithSetter
{
}
?>

