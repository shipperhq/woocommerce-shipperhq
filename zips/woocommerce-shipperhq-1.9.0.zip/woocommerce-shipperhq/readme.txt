=== ShipperHQ: Shipping & Checkout Experience Solution ===
Contributors: shipperhq
Tags: ecommerce, e-commerce, store, sales, sell, shipping, shipping rates, rating, rate management, cart, checkout, downloadable, downloads, shipperhq, shipper hq
Requires at least: 4.4
Tested up to: 6.8
Stable tag: 1.9.0
Requires PHP: 7.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Control the shipping rates and options you show in your WooCommerce cart. Live rates from 30+ carriers, LTL Freight and custom rates.

== Description ==

Create the perfect checkout experience for your customers and your business. ShipperHQ turns shipping from a cost center into your competitive advantage. With 15+ years of expertise in shipping and checkout optimization, ShipperHQ is trusted by thousands of brands across 150+ countries.

Built by merchants, for merchants, ShipperHQ gives you full control over your shipping logic and checkout with a powerful, no-code solution.  Tailor your checkout, shipping and rules to fit your business. Cut shipping costs, boost conversions and AOV and grow revenue with an Amazon-like checkout your customers will love.

With 50+ pre-built carrier integrations—including UPS, FedEx, DHL, USPS, Canada Post and LTL freight—ShipperHQ unifies your shipping operations in one centralized dashboard. Automated rate shopping then displays the best carrier at the best rate, every time.

Show real-time delivery dates, customize shipping logic and offer flexible promotions like free, tiered or flat-rate shipping. From dimensional packing and multi-origin fulfillment to international duties, tariffs, and LTL — ShipperHQ supports any shipping scenario.

Whether you’re shipping auto parts, artisan goods or anything in between, brands like Toyota, Cadbury, Pelican, and Stover & Company rely on ShipperHQ to deliver the fast, transparent shipping experience customers expect—and deserve.

ShipperHQ is proud to be a UPS Ready Premier Partner and a FedEx Alliance Partner.

== Why WooCommerce Sellers Love ShipperHQ ==

* 15+ years of proven success powering shipping and checkout for thousands of brands across 150+ countries.
* Custom-built flexibility delivered through a scalable, no-code shipping solution.
* Enterprise-grade reliability, security and data privacy built for eCommerce.
* Trusted by 50+ carriers and recognized as a UPS Ready Premier Partner—three years running.
* Local support from shipping experts who know the eCommerce business inside out.

[youtube https://www.youtube.com/watch?v=O2bfPFMO8pw]

== Key Features ==
* **Access Live Rates from 50+ Carriers**: Connect your carriers to your website with access to live rates from a wide range of global carriers, including 30+ LTL freight providers.
* **Handle Any Type of Shipping with Ease**: Easily customize shipping logic and rules for multi-origin orders, freight, restricted goods, perishables and more – so your checkout aligns with your logistics, no matter how complex.
* **Offer Exact Delivery Dates Every Time**: Show accurate delivery dates with custom lead times, cut-off times, blackout days, & max transit times.
* **Ship from Anywhere with Multi-Origin Shipping**: Ship from multiple warehouses, dropshippers or retail stores. Define rules to control where items ship from and how orders are rated.
* **Show Accurate Rates with Dimensional Packing**: Pack and rate products by size using your custom boxes and smart packing rules—powered by our best-fit algorithm—to deliver the most accurate rates at checkout.
* **Deliver the Small-Package Experience with LTL Freight**: Simplify LTL shipping to save time and money. Get real-time freight shipping rates from 30+ carriers and support for all freight classes.
* **Capture More Sales with In-Store Pickup**: Reduce cart abandonment and capture more shoppers by offering a convenient in-store pickup option.
* **Avoid Surprise Surcharges with Address Validation**: Automatically determine whether an address is residential or commercial, and charge the right amount for the right address type.
* **Calculate and Collect Duties & Taxes at Checkout**: Prevent unexpected fees, adapt to evolving tariffs, and improve customer experience with real-time calculations powered by DHL eCommerce. Works with any global carrier.

== Installation ==

Our [Help Docs](http://docs.shipperhq.com) provide detailed instructions on [how to install the ShipperHQ WooCommerce Plugin](https://docs.shipperhq.com/install-woocommerce-plugin) and more!

== Frequently Asked Questions ==

= What happens after 15 days? =
If you haven't set up billing during your 15 day trial period, your account will be deactivated. However, you will still have the ability to log in and set up billing to re-enable your account. Your settings will be saved for at least 30 days if you wish to re-activate. After 30 days of inactivity your account may be deleted.

= How long are your contracts? =
When signing up for a ShipperHQ plan, you are given the option to pay monthly or annually. On our Essentials, Standard and Pro plans, you have the option to cancel at any time. However, we do not provide a refund if you decide to cancel before your next auto-renewal period. If you are an Enterprise user, contracts are written on an individual basis.

== Screenshots ==

1. Get Live Rates from 50+ Carriers, including 30+ LTL Freight Providers
2. Customize Shipping Rules and Logic Your Way
3. Show Accurate Delivery Dates or Offer In-Store Pickup
4. Show Exact Shipping Rates with Dimensional Packing
5. Calculate and Collect Duties & Taxes at Checkout
6. Stop Losing Money on Shipping & Handle Any Shipping Scenario with Ease

== Try ShipperHQ for Free ==
See for yourself why thousands of brands trust ShipperHQ. Start your [15 day free trial now.](https://shipperhq.com/signup?platform=woocommerce&utm_source=woocommerce-marketplace&utm_medium=app-listing&utm_campaign=woocommerce-marketplace)

ShipperHQ plans are based on the shipping features you need. You can choose between monthly and annual billing options. [Plans start at $75/month.](https://shipperhq.com/plans?platform=woo+commerce&utm_campaign=core-tracking-external-partner-pages&utm_source=woocommerce-marketplace&utm_medium=referral&utm_content=woocommerce-pricing-plans)

== Free Offer For UPS Customers ==
ShipperHQ Lite for UPS®

Easily add UPS® shipping options at checkout to offer customers multiple delivery options from a trusted carrier. Enhance your WooCommerce checkout with [ShipperHQ's Free UPS offer](https://shipperhq.com/woocommerce).

== Changelog ==

= 1.9.0 - 2025-11-06
1.9.0 SHQ23-5796 Ensure compatibility with WooCommerce 10 and latest themes
= 1.8.0 - 2025-09-22
1.8.0 SHQ23-4808 Add support for place order call
= 1.7.1 - 2025-05-16 =
1.7.1 INFRA-1099 - Corrected ZIP format
= 1.7.0 - 2025-05-15 =
1.7.0 SHQ23-4773 Update to PHP8.4 compatible. Improve conformity to WordPress coding standards
= 1.7.0 - 2025-05-15 =
1.7.0  SHQ23-4773 Update to PHP8.4 compatible. Improve conformity to WordPress coding standards
= 1.6.4 - 2025-01-02 =
1.6.4 SHQ23-4085 Updating compatibility and readme
= 1.6.3 - 2024-07-03 =
1.6.3 SHQ23-2956 Updated Marketplace listing
= 1.6.2 - 2023-12-15 =
1.6.2 SHQ23-1570 Ensure app version is included in logs
= 1.6.1 - 2023-11-21 =
1.6.1 SHQ23-1393 Confirm compatibility with the latest versions of WooCommerce and WordPress
= 1.6.1 - 2023-11-21 =
1.6.1 SHQ23-1393 Confirm compatibility with the latest versions of WooCommerce and WordPress
= 1.6.0 - 2023-01-16 =
1.6.0 RIV-1302 Add new hook around populating formatted items. MNB-3277 Fixes around undefined index
= 1.5.1 - 2022-11-14 =
1.5.1 MNB-3170 Resolve Function wp_register_style was called incorrectly
= 1.5.0 - 2022-10-31 =
1.5.0 RIV-1247 Restyle delivery date messages on checkout. MNB-3056 Improve logic preventing empty rate requests being sent to ShipperHQ
= 1.4.12 - 2022-08-10 =
MNB-2727 Updates to Woo module listing readme
= 1.4.11 - 2022-07-05 =
MNB-2711 Fix for missing library
= 1.4.10 - 2022-06-29 =
MNB-2531 Add feature to reduce number of invalid requests being made to ShipperHQ & confirm compatibility with the latest versions of WooCommerce and WordPress
= 1.4.9 - 2021-09-27 =
MNB-1689 Confirm compatibility with the latest versions of WooCommerce and WordPress
= 1.4.8 - 2021-09-10 =
MNB-1601 Fix around getting origin information from carrier group
= 1.4.6 - 2021-07-26 =
MNB-1477 Display shipping origin in order details
= 1.4.5 - 2020-12-04 =
MNB-890 Update marketing copy
= 1.4.4 - 2020-10-29 =
MNB-567 Correct tooltips on product listing admin
= 1.4.3 - 2019-12-10 =
SHQ18-2977 Updated to work with new library-shipper
= 1.4.2 - 2019-12-05 =
SHQ18-2977 Fixed error when order does not have a shipping line
= 1.4.1 - 2019-10-02 =
SHQ18-2560 Updated lib-GraphQL for use with WooCommerce
= 1.4.0 - 2019-09-23 =
SHQ18-2560/SHQ18-2561 Add uShip Listing Feature
= 1.3.8 - 2019-05-31 =
SHQ18-2022 Added hs code to shipping attributes
= 1.3.7 - 2019-05-14 =
Maintenance release
= 1.3.6 - 2019-01-25 =
SHQ18-1204 Make methods around getting inventory status public so they can be extended
= 1.3.5 - 2018-12-05 =
SHQ18-1158 Prevent calling ShipperHQ API when credentials are missing
= 1.3.4 - 2018-11-27 =
SHQ18-1079 Support for WooCommerce product add on module
= 1.3.3 - 2018-10-31 =
SHQ18-1006 Fix issue with ship separately and must ship freight checlboxes
= 1.2.11 - 2017-10-11 =
SHQ16-2339 remove use of deprecated function
= 1.2.10 - 2017-10-09 =
Update to readme.txt for WordPress store release
= 1.2.9 - 2017-08-15 =
SHQ16-2216 modified headers and function name after review
= 1.2.8 - 2017-08-09 =
SHQ16-2202 Support for 2.6 and below version no parent_id


[See CHANGELOG.md for all versions](https://plugins.svn.wordpress.org/woo-shipperhq/trunk/CHANGELOG.md)

== Upgrade Notice ==

= 1.4.11 =
Update to this version to fix Class "ShipperHQ\WS\Shared\BasicAddress" not found introduced in 1.4.10
= 1.4.8 =
Update to this version to fix undefined offset error introduced in 1.4.6
= 1.4.3 =
Update to this version to fix issues with virtual products
= 1.3.5 =
Update to this version to prevent calls to ShipperHQ API unnecessarily
= 1.3.3 =
Update to this version to ensure must ship freight and ship separately checkboxes work
= 1.2.11 =
Update to this version to ensure compatibility with WooCommerce v3.0+
= 1.2.10 =
This version includes changes to the listing text
= 1.2.9 =
This version was submitted to WordPress for public release
