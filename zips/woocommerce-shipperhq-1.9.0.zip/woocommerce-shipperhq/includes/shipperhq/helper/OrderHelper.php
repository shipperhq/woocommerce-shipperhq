<?php
/*
 * ShipperHQ
 *
 * @category ShipperHQ
 * @package woocommerce-shipperhq
 * @copyright Copyright (c) 2020 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */

/**
 * Helper class for ShipperHQ order operations
 */
class ShipperHQ_OrderHelper {
	/**
	 * Order ID
	 * @var mixed
	 */
	private $order_id;
	/**
	 * WooCommerce Order object
	 * @var WC_Order|null
	 */
	private $order;
	/**
	 * Selected shipping method
	 * @var WC_Order_Item_Shipping|null
	 */
	private $selected_shipping_method = NULL;
	/**
	 * Shipping meta data
	 * @var array
	 */
	private $shipping_meta_data = NULL;

	/**
	 * ShipperHQ_OrderHelper constructor.
	 *
	 * @param mixed|null    $order_id The order ID.
	 * @param WC_Order|null $order    The order object.
	 */
	public function __construct( $order_id = NULL, $order = NULL ) {
		if ( $order ) {
			$this->set_order( $order );

			return;
		} elseif ( $order_id ) {
			$this->set_order_id( $order_id );

			return;
		}
	}

	/**
	 * Set the order ID
	 *
	 * @param mixed $order_id The order ID.
	 *
	 * @return $this
	 */
	public function set_order_id( $order_id ) {
		$this->order_id = $order_id;
		$this->order    = wc_get_order( $order_id );
		$this->reset_memoized_data();

		return $this;
	}

	/**
	 * Set the order object
	 *
	 * @param WC_Order $order The order object.
	 *
	 * @return $this
	 */
	public function set_order( $order ) {
		$this->order    = $order;
		$this->order_id = $order->get_id();
		$this->reset_memoized_data();

		return $this;
	}

	/**
	 * Check if the shipping method is uShip
	 * @return bool
	 */
	public function shipping_method_is_uship() {
		// SHQ18-2977 - Virtual product only shipments will not have a shipping line item
		if ( ! $this->get_selected_shipping_method() ) {
			return FALSE;
		}
		$type = $this->extract_shipping_meta_data_by_key( 'carrier_type' );

		return FALSE !== stripos( $type, 'uship' );
	}

	/**
	 * Extract shipping meta-data by key
	 *
	 * @param string $key The meta-key.
	 *
	 * @return mixed
	 */
	public function extract_shipping_meta_data_by_key( $key ) {
		return $this->extract_meta_data_by_key( $this->get_shipping_meta_data(), $key );
	}

	/**
	 * Get the selected shipping method
	 * @return mixed|WC_Order_Item_Shipping|null
	 */
	public function get_selected_shipping_method() {
		if ( ! $this->selected_shipping_method && $this->order ) {
			$shipping_methods = $this->order->get_shipping_methods();
			if ( ! empty( $shipping_methods ) ) {
				$this->selected_shipping_method = array_shift( $shipping_methods );
			}
		}

		return $this->selected_shipping_method;
	}

	/**
	 * Reset memoized data
	 */
	private function reset_memoized_data() {
		$this->selected_shipping_method = NULL;
		$this->shipping_meta_data       = NULL;
	}

	/**
	 * Get shipping meta data
	 * @return array
	 */
	private function get_shipping_meta_data() {
		if ( ! $this->shipping_meta_data ) {
			$selected_method          = $this->get_selected_shipping_method();
			$this->shipping_meta_data = $selected_method ? $selected_method->get_meta_data() : [];
		}

		return $this->shipping_meta_data;
	}

	/**
	 * Extract meta-data by key
	 *
	 * @param array  $method_meta_data The meta data.
	 * @param string $key              The meta key.
	 *
	 * @return mixed
	 */
	private function extract_meta_data_by_key( $method_meta_data, $key ) {
		$value = '';
		if ( ! is_array( $method_meta_data ) ) {
			return $value;
		}
		foreach ( $method_meta_data as $meta_data ) {
			$data = $meta_data->get_data();
			if ( isset( $data['key'] ) && $key === $data['key'] ) {
				$value = isset( $data['value'] ) ? $data['value'] : '';
				break;
			}
		}

		return $value;
	}
}
