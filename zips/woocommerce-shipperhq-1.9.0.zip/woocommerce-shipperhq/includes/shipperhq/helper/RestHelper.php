<?php
/*
 * ShipperHQ
 *
 * @category ShipperHQ
 * @package woocommerce-shipperhq
 * @copyright Copyright (c) 2020 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */

class ShipperHQ_RestHelper {
	private string $_testUrl = "http://www.localhost.com:8080/shipperhq-ws/v1/";
	private string $_liveUrl = "https://api.shipperhq.com/v1/";
	private string $_postOrderLiveUrl = "https://postapi.shipperhq.com/v1/";
	private string $_postOrderTestUrl = "http://localhost:8081/label-ws/v1/";
	private bool $_sandboxMode;

	public function __construct( $sandboxMode ) {
		if ( function_exists( 'wc_string_to_bool' ) ) {
			$this->_sandboxMode = wc_string_to_bool( $sandboxMode );
		} else {
			$this->_sandboxMode = $this->normaliseBoolean( $sandboxMode );
		}
	}

    /**
     * Normalise a mixed truthy/falsey value to a strict boolean.
     * Falls back gracefully if WooCommerce helper is unavailable.
     *
     * @param mixed $value
     * @return bool
     */
    public function normaliseBoolean($value ): bool {
        if ( is_bool( $value ) ) {
            return $value;
        }

        if ( is_string( $value ) ) {
            $normalized = strtolower( trim( $value ) );
            if ( in_array( $normalized, [ 'yes', 'true', '1', 'on', 'y' ], true ) ) {
                return true;
            }
            if ( in_array( $normalized, [ 'no', 'false', '0', 'off', 'n', '' ], true ) ) {
                return false;
            }
        }

        $filtered = filter_var( $value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE );
        return $filtered !== null ? $filtered : (bool) $value;
    }

	/**
	 * Returns url to use - live if present, otherwise dev
	 *
	 * @return string
	 */
	protected function _getGatewayUrl(): string {
		return $this->_sandboxMode ? $this->_testUrl : $this->_liveUrl;
	}

	/**
	 * Returns the PostOrder API URL
	 *
	 * @return string
	 */
	protected function _getPostOrderUrl(): string {
		return $this->_sandboxMode ? $this->_postOrderTestUrl : $this->_postOrderLiveUrl;
	}

	/**
	 * Retrieve url for getting allowed methods
	 * @return string
	 */
	public function getAllowedMethodGatewayUrl(): string {
		return $this->_getGatewayUrl() . 'allowed_methods';
	}

	/**
	 * Retrieve url for getting shipping rates
	 * @return string
	 */
	public function getRateGatewayUrl(): string {
		return $this->_getGatewayUrl() . 'rates';
	}

	/**
	 * Retrieve url for retrieving attributes
	 * @return string
	 */
	public function getAttributeGatewayUrl(): string {
		return $this->_getGatewayUrl() . 'attributes/get';
	}

	/**
	 * Retrieve url for checking if attributes are synchronized
	 * @return string
	 */
	public function getCheckSynchronizedUrl(): string {
		return $this->_getGatewayUrl() . 'attributes/check';
	}

	/**
	 * Retrieve url for PlaceOrder REST endpoint
	 * @return string
	 */
	public function getPlaceOrderUrl(): string {
		return $this->_getPostOrderUrl() . 'placeorder';
	}
}
