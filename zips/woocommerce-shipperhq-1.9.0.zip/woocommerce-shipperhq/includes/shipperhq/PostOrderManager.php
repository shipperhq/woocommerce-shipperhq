<?php
/*
 * ShipperHQ
 *
 * @category ShipperHQ
 * @package woocommerce-shipperhq
 * @copyright Copyright (c) 2025 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ShipperHQ_Post_Order_Manager
 * Handles sending order details to ShipperHQ API on successful order placement
 */
class ShipperHQ_Post_Order_Manager {

	/**
	 * Logger instance
	 * @var WC_Logger
	 */
	private WC_Logger $logger;

	/**
	 * ShipperHQ settings
	 * @var array
	 */
	private mixed $settings;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->logger = new WC_Logger();
		$this->settings = get_option( 'woocommerce_shipperhq_settings', array() );
	}

	/**
	 * Check if order recording is enabled
	 *
	 * @return bool
	 */
	private function is_record_order_enabled(): bool {
		return isset( $this->settings['store_quote_order'] ) && 'yes' === $this->settings['record_order'];
	}

	/**
	 * Check if the shipping method is a ShipperHQ method
	 *
	 * @param string $shipping_method
	 *
	 * @return bool
	 */
	private function is_shipperhq_method( string $shipping_method ): bool {
		// Check if it's a direct ShipperHQ method or multicarrier
		return strstr( $shipping_method, 'shq' ) !== false || 
		       strstr( $shipping_method, 'shipperhq' ) !== false || 
		       strstr( $shipping_method, 'multicarrier' ) !== false;
	}

	/**
	 * Main method to handle order recording
	 * Replicates the functionality of Magento's AbstractRecordOrder::recordOrder()
	 *
	 * @param int $order_id The WooCommerce order ID
	 *
	 * @return bool Success status
	 */
	public function record_order( int $order_id ): bool {
		// Check if recording is enabled
		if ( ! $this->is_record_order_enabled() ) {
			$this->logger->add( 'ShipperHQ', 'Order recording is disabled in settings', WC_Log_Levels::DEBUG );
			return false;
		}

		try {
			// Get the order
			$order = wc_get_order( $order_id );
			if ( ! $order ) {
				$this->logger->add( 'ShipperHQ', "Order not found: {$order_id}", WC_Log_Levels::ERROR );
				return false;
			}

			// Check if order has virtual products only (no shipping needed)
			if ( ! $order->needs_shipping_address() ) {
				$this->logger->add( 'ShipperHQ', "Order {$order_id} contains only virtual products, skipping", WC_Log_Levels::DEBUG );
				return false;
			}

			// Get shipping methods used in the order
			$shipping_methods = $order->get_shipping_methods();
			$has_shipperhq_method = false;

			foreach ( $shipping_methods as $shipping_method ) {
				if ( $this->is_shipperhq_method( $shipping_method->get_method_id() ) ) {
					$has_shipperhq_method = true;
					break;
				}
			}

			// Only process if at least one ShipperHQ method is used
			if ( ! $has_shipperhq_method ) {
				$this->logger->add( 'ShipperHQ', "Order {$order_id} does not use ShipperHQ shipping methods, skipping", WC_Log_Levels::DEBUG );
				return false;
			}

			$this->logger->add( 'ShipperHQ', "Starting order recording for order: {$order_id}", WC_Log_Levels::INFO );

			// Send order details to ShipperHQ API
			$result = $this->send_order_to_api( $order );

			if ( $result ) {
				$this->logger->add( 'ShipperHQ', "Successfully recorded order: {$order_id}", WC_Log_Levels::INFO );
				// Add order note
				$order->add_order_note( __( 'Order details sent to ShipperHQ successfully', 'woocommerce-shipperhq' ) );
			} else {
				$this->logger->add( 'ShipperHQ', "Failed to record order: {$order_id}", WC_Log_Levels::ERROR );
				// Add order note about failure
				$order->add_order_note( __( 'Failed to send order details to ShipperHQ', 'woocommerce-shipperhq' ) );
			}

			return $result;

		} catch ( Exception $e ) {
			$this->logger->add( 'ShipperHQ', "Exception recording order {$order_id}: " . $e->getMessage(), WC_Log_Levels::ERROR );
			return false;
		}
	}

	/**
	 * Send order details to ShipperHQ API using the library-ws WebServiceClient
	 * This replicates the pattern used in ShippingMethod.php
	 *
	 * @param WC_Order $order
	 *
	 * @return bool Success status
	 */
	private function send_order_to_api( WC_Order $order ): bool {
		try {
					// Include required libraries
		$this->include_ws_libs();

		// Prepare order data for PlaceOrder API
		$order_data = $this->prepare_order_data( $order );
		
		if ( false === $order_data ) {
			$this->logger->add( 'ShipperHQ', 'Could not prepare order data for PlaceOrder API', WC_Log_Levels::ERROR );
			return false;
		}

		// Get API credentials
		$api_key = $this->settings['api_key'] ?? '';
		$auth_code = $this->settings['authentication_code'] ?? '';

		if ( empty( $api_key ) || empty( $auth_code ) ) {
			$this->logger->add( 'ShipperHQ', 'API credentials not configured', WC_Log_Levels::ERROR );
			return false;
		}

		// Create credentials object
		$credentials = new ShipperHQ\WS\Shared\Credentials( $api_key, $auth_code );

		// Get site details from Mapper (follows existing pattern)
		require_once plugin_dir_path( __FILE__ ) . 'helper/Mapper.php';
		$mapper = new ShipperHQ_Mapper();
		$site_details = $mapper->getSiteDetails();

		// Create recipient address from order shipping address
		$recipient = $this->getRecipient( $order );

		// Create PlaceOrder request with all required fields
		$request = new ShipperHQ\WS\PostOrder\Placeorder\Request\PlaceOrderRequest(
			$order_data['orderNumber'],
			$order_data['totalCharges'],
			$order_data['carrierCode'],
			$order_data['methodCode'],
			$order_data['transId'],
			$order->get_date_created()->format('Y-m-d\TH:i:s'),
			$recipient,
			$order->get_subtotal() // TODO check this doesnt include shipping fee
		);
		
		// Set credentials and site details
		$request->setCredentials( $credentials );
		$request->setSiteDetails( $site_details );

			// Get sandbox mode and create RestHelper
			$sandbox_mode = $this->settings['sandbox_mode'] ?? 'no';
			$rest_helper = new ShipperHQ_RestHelper( $sandbox_mode );

			// Get timeout setting
			$timeout = isset( $this->settings['ws_timeout'] ) ? intval( $this->settings['ws_timeout'] ) : 30;

			// Use WebServiceClient to send request
			$web_service_client = new ShipperHQ\WS\Client\WebServiceClient();
			$result_set = $web_service_client->sendAndReceiveWp( 
				$request, 
				$rest_helper->getPlaceOrderUrl(),
				$timeout 
			);

			// Log the request and response for debugging
			if ( isset( $result_set['debug'] ) ) {
				$this->logger->add( 'ShipperHQ', 'Record Order request and result: ' . print_r( $result_set['debug'], true ), WC_Log_Levels::DEBUG );
			}

			// Check if request was successful
			if ( ! isset( $result_set['result'] ) || ! $result_set['result'] ) {
				$this->logger->add( 'ShipperHQ', 'Record Order API request failed', WC_Log_Levels::ERROR );
				return false;
			}

			$this->logger->add( 'ShipperHQ', 'Record Order API request successful', WC_Log_Levels::INFO );
			return true;

		} catch ( Exception $e ) {
			$this->logger->add( 'ShipperHQ', 'Exception in Record Order API call: ' . $e->getMessage(), WC_Log_Levels::ERROR );
			return false;
		}
	}

	/**
	 * Include required WebService libraries
	 * Following the same pattern as ShippingMethod.php
	 */
	private function include_ws_libs(): void {
		$shq_dir = plugin_dir_path( __FILE__ ) . '..';
		
		require_once( $shq_dir . '/external/lib/library-ws/src/Shared/Credentials.php' );
		require_once( $shq_dir . '/external/lib/library-ws/src/Shared/SiteDetails.php' );
		require_once( $shq_dir . '/external/lib/library-ws/src/Shared/BasicAddress.php' );
		require_once( $shq_dir . '/external/lib/library-ws/src/WebServiceRequestInterface.php' );
		require_once( $shq_dir . '/external/lib/library-ws/src/AbstractWebServiceRequest.php' );
		require_once( $shq_dir . '/external/lib/library-ws/src/Client/WebServiceClient.php' );
		require_once( $shq_dir . '/external/lib/library-ws/src/PostOrder/Placeorder/Request/PlaceOrderRequest.php' );
	}

	/**
	 * Prepare minimal order data for PlaceOrder API
	 * Based on ShipperHQ PlaceOrder mutation requirements
	 *
	 * @param WC_Order $order
	 *
	 * @return array
	 */
	private function prepare_order_data( WC_Order $order ): false|array {
		// Get the first ShipperHQ shipping method
		$shipping_methods = $order->get_shipping_methods();
		$shipperhq_method = null;
		
		foreach ( $shipping_methods as $shipping_method ) {
			if ( $this->is_shipperhq_method( $shipping_method->get_method_id() ) ) {
				$shipperhq_method = $shipping_method;
				break;
			}
		}

		if ( ! $shipperhq_method ) {
			$this->logger->add( 'ShipperHQ', 'No ShipperHQ shipping method found for order: ' . $order->get_id(), WC_Log_Levels::ERROR );
			return false;
		}

		// Extract required data from shipping method metadata
		$method_meta = $shipperhq_method->get_meta_data();
		$carrier_code = '';
		$method_code = '';
		$trans_id = '';

		foreach ( $method_meta as $meta ) {
			$data = $meta->get_data();
			switch ( $data['key'] ) {
				case 'carrier_code':
					$carrier_code = $data['value'];
					break;
				case 'method_code':
					$method_code = $data['value'];
					break;
				case 'carriergroup_detail':
					$trans_id = $data['value']['transaction'];
					break;
			}
		}

		// Fallback to method ID if method_code not found in metadata
		if ( empty( $method_code ) ) {
			$method_code = $shipperhq_method->get_method_title();
		}

		// Prepare minimal PlaceOrder data (matches ShipperHQ API requirements)
		return array(
			'orderNumber' => $order->get_order_number(),
			'totalCharges' => floatval( $shipperhq_method->get_total() ),
			'carrierCode' => $carrier_code,
			'methodCode' => $method_code,
			'transId' => $trans_id,
		);
	}

	/**
	 * Create recipient address from WooCommerce order
	 *
	 * @param WC_Order $order
	 * @return ShipperHQ\WS\Shared\BasicAddress
	 */
	private function getRecipient( WC_Order $order ): ShipperHQ\WS\Shared\BasicAddress {
		$recipient = new ShipperHQ\WS\Shared\BasicAddress();
		
		$recipient->city = $order->get_shipping_city() ?? '';
		$recipient->country = $order->get_shipping_country() ?? '';
		$recipient->region = $order->get_shipping_state() ?? '';
		$recipient->street = $order->get_shipping_address_1() ?? '';
		$recipient->street2 = $order->get_shipping_address_2() ?? '';
		$recipient->zipcode = $order->get_shipping_postcode() ?? '';
		
		return $recipient;
	}
}