<?php
/*
 * ShipperHQ
 *
 * @category ShipperHQ
 * @package woocommerce-shipperhq
 * @copyright Copyright (c) 2020 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ShipperHQ_Shipping
 * Handles shipping integration with ShipperHQ
 */
class ShipperHQ_Shipping {
	/**
	 * Constructor - register hooks
	 */
	public function __construct() {
		add_action( 'woocommerce_shipping_methods', array( $this, 'add_shipperhq_methods' ) );
		// Initialize shipping method class
		add_action( 'woocommerce_shipping_init', array( $this, 'init_shipping_file' ) );
		// Setup placeOrder handlers (classic checkout and Checkout Blocks)
		add_action( 'woocommerce_checkout_order_created', array( $this, 'handle_wc_checkout_order_created' ), 10, 1 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'handle_store_api_checkout_order_processed' ), 10, 1 );
		// Add CSS selectors to shipping methods and split estimated delivery dates into new line
		add_action( 'woocommerce_after_shipping_rate', array( $this, 'checkout_shipping_add_css' ), 10, 2 );
		// Adjust the method name to add back in the estimated delivery date info if required
		add_action( 'woocommerce_checkout_create_order_shipping_item', array( $this, 'checkout_shipping_adjust_method_name' ), 10, 4 );
		// Add CSS to shipping methods
		add_action( 'wp_enqueue_scripts', array( $this, 'add_shipperhq_styles' ) );
		// Populate delivery_time on WC_Shipping_Rate so Checkout Blocks can render it
		add_filter( 'woocommerce_shipping_method_add_rate', array( $this, 'add_delivery_time_to_rate' ), 20, 3 );
	}

	/**
	 * Adds the CSS for the cart and checkout page
	 * @return void
	 */
	public function add_shipperhq_styles() {
		wp_enqueue_style(
			'shipperhq_styles',
			plugins_url( 'assets/css/shipperhq-styles.css', WC_SHIPPERHQ_ROOT_FILE ),
			array(),
			WooCommerce_ShipperHQ::get_instance()->version
		);
	}

	/**
	 * Populate the method description with the estimated delivery date - this is used by newer themes and supersedes
     * the other technique of adding estimated dates in checkout_shipping_add_css
	 *
	 * @param WC_Shipping_Rate   $rate    The rate object.
	 * @param array              $args    Original args passed to add_rate.
	 * @param WC_Shipping_Method $method  Method instance creating the rate.
	 *
	 * @return WC_Shipping_Rate
	 */
	public function add_delivery_time_to_rate( $rate, $args, $method ) {
		if ( isset( $method->id ) && $method->id === 'shipperhq' ) {
			$meta_data = isset( $args['meta_data'] ) && is_array( $args['meta_data'] ) ? $args['meta_data'] : array();
			$desc      = isset( $meta_data['method_description'] ) ? (string) $meta_data['method_description'] : '';
			if ( $desc ) {
				if ( is_callable( array( $rate, 'set_description' ) ) ) {
					$rate->set_description( $desc );
				}
			}
		}

		return $rate;
	}

	/**
	 * RIV-1247 Sets the shipping method name to method name with delivery message appended.
	 * Ensures backward compatibility
     * This runs when the method is selected in checkout and also on place order
	 *
	 * @param WC_Order_Item_Shipping $item        The shipping item.
	 * @param int                    $package_key The package key.
	 * @param array                  $package     The package data.
	 * @param WC_Order               $order       The order object.
	 *
	 * @return void
	 * @throws WC_Data_Exception
	 */
	public function checkout_shipping_adjust_method_name( $item, $package_key, $package, $order ) {
		$method_description = $item->get_meta( "method_description" );
		if ( ! empty( $method_description ) ) {
			$item->set_method_title( $item->get_method_title() . ' ' . __( $method_description, 'woocommerce-shipperhq' ) );
		}
	}

	/**
	 * RIV-1247 Adds CSS class to method description which holds the estimated delivery date if present
	 *
     * @deprecated This is not used by modern themes which instead use add_delivery_time_to_rate
	 * @param WC_Shipping_Method $method The shipping method.
	 * @param int                $index  The index.
	 *
	 * @return void
	 */
    public function checkout_shipping_add_css( $method, $index ) {
		if ( $method->get_method_id() == "shipperhq" ) {
			$meta_data = $method->get_meta_data();
			if ( isset( $meta_data['method_description'] ) && ! empty( $meta_data['method_description'] ) ) {
				echo '<span id="shipperhq-method-description" class="shipperhq-method-description">' .
				     esc_html( $meta_data['method_description'] ) .
				     '</span>';
			}
		}
	}

	public function add_shipperhq_methods( $methods ) {
		$methods[] = 'ShipperHQ_Shipping_Method';

		return $methods;
	}

	public function init_shipping_file() {
		/**
		 * Shipping method class
		 */
		require_once plugin_dir_path( __FILE__ ) . '/ShippingMethod.php';
	}

	/**
	 * Handle order creation - potentially create shipping listing
	 *
	 * @param int $order_id The order ID.
	 *
	 * @return void
	 */
	public function handle_wc_checkout_update_order_meta( $order_id ): void {
		$this->process_post_order( $order_id );
	}

	/**
	 * Handle order created event (classic checkout)
	 *
	 * @param WC_Order $order The order object.
	 *
	 * @return void
	 */
	public function handle_wc_checkout_order_created( $order ): void {
		if ( $order instanceof WC_Order ) {
			$this->process_post_order( $order->get_id() );
		}
	}

	/**
	 * Handle Store API checkout update order meta (Checkout Blocks)
	 *
	 * @param WC_Order $order The order object.
	 *
	 * @return void
	 */
	public function handle_store_api_checkout_order_processed( $order ): void {
		if ( $order instanceof WC_Order ) {
			$this->process_post_order( $order->get_id() );
		}
	}

	/**
	 * Shared post-order processing logic
	 *
	 * @param int $order_id The order ID.
	 *
	 * @return void
	 */
	private function process_post_order( $order_id ): void {
		require_once plugin_dir_path( __FILE__ ) . '/ListingManager.php';
		require_once plugin_dir_path( __FILE__ ) . '/PostOrderManager.php';
		require_once plugin_dir_path( __FILE__ ) . '/helper/OrderHelper.php';

		$order_helper            = new ShipperHQ_OrderHelper( $order_id );
		$settings                = get_option( 'woocommerce_shipperhq_settings', array() );
		$auto_listing_is_enabled = isset( $settings['create_listing'] ) && 'AUTO' === $settings['create_listing'];

		// SHQ18-2977 - Check if we even need to create a listing before wasting further effort
		if ( $auto_listing_is_enabled && $order_helper->shipping_method_is_uship() ) {
			$listing_manager = new ShipperHQ_Listing_Manager();
			$listing_manager->create_listing_for_order( $order_id );
		}

		// Record order details to ShipperHQ API (replicates Magento postOrderHelper->handleOrder functionality)
		$post_order_manager = new ShipperHQ_Post_Order_Manager();
		$post_order_manager->record_order( $order_id );
	}
}
