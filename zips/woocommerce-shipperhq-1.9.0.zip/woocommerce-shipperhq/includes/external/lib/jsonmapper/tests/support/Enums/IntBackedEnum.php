<?php

declare(strict_types=1);

namespace Enums;

enum IntBackedEnum: int
{
    case FOO = 1;
    case BAR = 2;
}
