<?php

declare(strict_types=1);

namespace Enums;

class ObjectWithEnum
{
    public StringBackedEnum $stringBackedEnum;
    public IntBackedEnum $intBackedEnum;
}
