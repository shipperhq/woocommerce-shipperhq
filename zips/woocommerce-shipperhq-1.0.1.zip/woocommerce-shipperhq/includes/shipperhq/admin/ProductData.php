<?php
/* ExtName
 *
 * User        karen
 * Date        6/12/16
 * Time        1:44 PM
 * @category   Webshopapps
 * @package    Webshopapps_ExtnName
 * @copyright   Copyright (c) 2015 Zowta Ltd (http://www.WebShopApps.com)
 *              Copyright, 2015, Zowta, LLC - US license
 * @license    http://www.webshopapps.com/license/license.txt - Commercial license
 */

class ShipperHQ_ProductData {


    public function __construct()
    {

        add_filter( 'woocommerce_product_data_tabs', array( $this, 'shq_product_data_shipping_tab' ) );

        add_action( 'woocommerce_product_data_panels', array( $this, 'shq_product_data_shipping_panel' ) );

        add_action( 'woocommerce_process_product_meta_simple', array( $this, 'save_shq_product_data' ) );
        add_action( 'woocommerce_process_product_meta_grouped', array( $this, 'save_shq_product_data' ) );
        add_action( 'woocommerce_process_product_meta_external', array( $this, 'save_shq_product_data' ) );
        add_action( 'woocommerce_process_product_meta_variable', array( $this, 'save_shq_product_data' ) );
    }

    public function shq_product_data_shipping_tab( $tabs)
    {

        $tabs['shipperhq'] = array(
            'label'  => __( 'ShipperHQ', 'woocommerce-shipperhq' ),
            'target' => 'shipperhq_product_data',
            'class'  => array( '' ),
        );

        return $tabs;
    }

    public function shq_product_data_shipping_panel()
    {

        ?><div id="shipperhq_product_data" class="panel woocommerce_options_panel"><?php

        woocommerce_wp_text_input( array(
            'id' 		=> 'shipperhq_shipping_group',
            'desc_tip'    => 'true',
            'placeholder' => "Optional",
            'description' => __( 'Enter Shipping Groups, comma separated if multiple.', 'woocommerce' ),
            'label' 	=> __( 'Shipping Group(s)', 'woocommerce-shipperhq' ),
        ) );

        woocommerce_wp_text_input( array(
            'id' 		=> 'shipperhq_dim_group',
            'placeholder' => "Optional",
            'desc_tip'    => 'true',
            'description' => __( 'Enter Dimensional Rule Groups, comma separated if multiple.', 'woocommerce' ),
            'label' 	=> __( 'Dimensional Rule Group', 'woocommerce-shipperhq' ),
        ) );


        woocommerce_wp_checkbox( array(
            'id' 			=> 'ship_separately',
            'label' 		=> __( 'Ships Separately', 'woocommerce-shipperhq' ),
            'desc_tip'    => 'true',
            'description' => __( 'Does this product ship on its on?', 'woocommerce' )
        ) );

        woocommerce_wp_text_input( array(
            'id' 		=> 'shipperhq_warehouse',
            'placeholder' => "Optional",
            'desc_tip'    => 'true',
            'description' => __( 'Assigned Warehouses, comma separated if multiple.', 'woocommerce' ),
            'label' 	=> __( 'Warehouse(s)', 'woocommerce-shipperhq' ),
        ) );

        woocommerce_wp_select( array(
            'id' 			=> 'freight_class',
            'label' 		=> __( 'Freight class', 'woocommerce-shipperhq' ),
            'options' 		=> array(
                'NONE'	=> 'NONE',
                '50'	=> '50',
                '55'	=> '55',
                '60'	=> '60',
                '65'	=> '65',
                '70'	=> '70',
                '77.5'	=> '77.5',
                '85'	=> '85',
                '92.5'	=> '92.5',
                '100'	=> '100',
                '110'	=> '110',
                '125'	=> '125',
                '150'	=> '150',
                '175'	=> '175',
                '200'	=> '200',
                '250'	=> '250',
                '300'	=> '300',
                '400'	=> '400',
                '500'	=> '500',
            )
        ) );


        woocommerce_wp_checkbox( array(
            'id' 			=> 'must_ship_freight',
            'label' 		=> __( 'Must Ship Freight', 'woocommerce-shipperhq' ),
            'desc_tip'    => 'true',
            'description' => __( 'Select if item only ships Freight.', 'woocommerce' )
        ) );

        ?></div><?php

    }

    public function save_shq_product_data($post_id) {
        update_post_meta( $post_id, 'must_ship_freight', $_POST['must_ship_freight'] );
        update_post_meta( $post_id, 'freight_class', $_POST['freight_class'] );
        update_post_meta( $post_id, 'shipperhq_warehouse', $_POST['shipperhq_warehouse'] );
        update_post_meta( $post_id, 'shipperhq_shipping_group', $_POST['shipperhq_shipping_group'] );
        update_post_meta( $post_id, 'shipperhq_dim_group', $_POST['shipperhq_dim_group'] );

    }
}