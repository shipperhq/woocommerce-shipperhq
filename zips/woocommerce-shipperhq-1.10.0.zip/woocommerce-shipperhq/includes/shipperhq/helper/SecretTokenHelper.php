<?php
/*
 * ShipperHQ
 *
 * @category ShipperHQ
 * @package woocommerce-shipperhq
 * @copyright Copyright (c) 2020 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */

/**
 * Fetches, validates, and caches JWT secret tokens from RMS (Rate Manager Server)
 * via the createSecretToken GraphQL mutation. Tokens authenticate OVS API requests.
 */
class ShipperHQ_SecretToken_Helper {

	const SETTINGS_KEY         = 'woocommerce_shipperhq_settings';
	const TOKEN_KEY            = 'secret_token';
	const TOKEN_EXP_KEY        = 'secret_token_exp';
	const REFRESH_THRESHOLD    = 3600;
	const REQUEST_TIMEOUT      = 30;

	/** @var ShipperHQ_OVS_UrlResolver */
	private $urlResolver;

	public function __construct( $urlResolver = null ) {
		$this->urlResolver = $urlResolver ?: new ShipperHQ_OVS_UrlResolver();
	}

	/**
	 * Get a valid secret token, using cache when possible.
	 *
	 * @return string|false The JWT token string, or false on failure.
	 */
	public function get_token() {
		$settings  = get_option( self::SETTINGS_KEY, array() );
		$api_key   = isset( $settings['api_key'] ) ? $settings['api_key'] : '';
		$auth_code = isset( $settings['authentication_code'] ) ? $settings['authentication_code'] : '';

		if ( empty( $api_key ) || empty( $auth_code ) ) {
			return false;
		}

		$cached_token = isset( $settings[ self::TOKEN_KEY ] ) ? $settings[ self::TOKEN_KEY ] : '';
		$cached_exp   = isset( $settings[ self::TOKEN_EXP_KEY ] ) ? (int) $settings[ self::TOKEN_EXP_KEY ] : 0;

		if ( ! empty( $cached_token ) && ! $this->token_expires_soon( $cached_exp ) ) {
			return $cached_token;
		}

		return $this->fetch_token_from_rms( $api_key, $auth_code );
	}

	/**
	 * Clear the cached token from settings.
	 */
	public function clear_cached_token() {
		$settings = get_option( self::SETTINGS_KEY, array() );
		unset( $settings[ self::TOKEN_KEY ] );
		unset( $settings[ self::TOKEN_EXP_KEY ] );
		update_option( self::SETTINGS_KEY, $settings );
	}

	/**
	 * @param int $expiration Unix timestamp
	 *
	 * @return bool
	 */
	private function token_expires_soon( int $expiration ): bool {
		return $expiration < ( time() + self::REFRESH_THRESHOLD );
	}

	/**
	 * Fetch a new token from RMS via the createSecretToken GraphQL mutation.
	 *
	 * @param string $api_key
	 * @param string $auth_code
	 *
	 * @return string|false
	 */
	private function fetch_token_from_rms( string $api_key, string $auth_code ) {
		$url   = $this->urlResolver->get_rms_url();
		$query = 'mutation CreateSecretToken($api_key: String!, $auth_code: String!) { '
		       . 'createSecretToken(api_key: $api_key, auth_code: $auth_code) { token } }';

		$body = wp_json_encode( array(
			'query'     => $query,
			'variables' => array(
				'api_key'   => $api_key,
				'auth_code' => $auth_code,
			),
		) );

		$response = wp_remote_post( $url, array(
			'timeout' => self::REQUEST_TIMEOUT,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body'    => $body,
		) );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$status = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status ) {
			return false;
		}

		$response_body = wp_remote_retrieve_body( $response );
		$parsed        = json_decode( $response_body, true );

		$token = isset( $parsed['data']['createSecretToken']['token'] )
			? $parsed['data']['createSecretToken']['token']
			: '';

		if ( empty( $token ) ) {
			return false;
		}

		return $this->validate_and_cache_token( $token, $auth_code );
	}

	/**
	 * Validate JWT signature and cache the token.
	 *
	 * @param string $jwt
	 * @param string $secret
	 *
	 * @return string|false
	 */
	private function validate_and_cache_token( string $jwt, string $secret ) {
		if ( ! $this->verify_jwt_signature( $jwt, $secret ) ) {
			return false;
		}

		$payload = $this->decode_jwt_payload( $jwt );
		if ( false === $payload ) {
			return false;
		}

		$exp = isset( $payload['exp'] ) ? (int) $payload['exp'] : 0;
		if ( $exp <= time() ) {
			return false;
		}

		$settings = get_option( self::SETTINGS_KEY, array() );
		$settings[ self::TOKEN_KEY ]     = $jwt;
		$settings[ self::TOKEN_EXP_KEY ] = $exp;
		update_option( self::SETTINGS_KEY, $settings );

		return $jwt;
	}

	/**
	 * Verify HMAC-SHA256 JWT signature.
	 *
	 * @param string $jwt
	 * @param string $secret
	 *
	 * @return bool
	 */
	private function verify_jwt_signature( string $jwt, string $secret ): bool {
		$parts = explode( '.', $jwt );
		if ( count( $parts ) !== 3 ) {
			return false;
		}

		$expected = hash_hmac( 'sha256', $parts[0] . '.' . $parts[1], $secret, true );
		$actual   = $this->base64url_decode( $parts[2] );

		return hash_equals( $expected, $actual );
	}

	/**
	 * Decode the JWT payload.
	 *
	 * @param string $jwt
	 *
	 * @return array|false
	 */
	private function decode_jwt_payload( string $jwt ) {
		$parts = explode( '.', $jwt );
		if ( count( $parts ) !== 3 ) {
			return false;
		}

		$payload = json_decode( $this->base64url_decode( $parts[1] ), true );

		return is_array( $payload ) ? $payload : false;
	}

	/**
	 * Base64url decode.
	 *
	 * @param string $data
	 *
	 * @return string
	 */
	private function base64url_decode( string $data ): string {
		return base64_decode( strtr( $data, '-_', '+/' ) );
	}
}
