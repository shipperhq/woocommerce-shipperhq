<?php
/*
 * ShipperHQ
 *
 * @category ShipperHQ
 * @package woocommerce-shipperhq
 * @copyright Copyright (c) 2020 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */

/**
 * Resolves URLs for OVS-related services (RMS, OVS, client bundle) based on
 * sandbox mode and WC_SHIPPERHQ_* constant overrides for local development.
 */
class ShipperHQ_OVS_UrlResolver {

	const RMS_LIVE_URL    = 'https://rms.shipperhq.com';
	const RMS_SANDBOX_URL = 'http://localhost:4000';

	const OVS_LIVE_URL    = 'https://ovs.shipperhq.com';
	const OVS_SANDBOX_URL = 'http://localhost:4060';

	const BUNDLE_VERSION  = '1.48.0';
	const BUNDLE_LIVE_URL = 'https://assets.shipperhq.com/shq-order-view_1.48.0.js';
	const BUNDLE_DEV_URL  = 'http://localhost:4091/dist/shq-order-view.js';

	/**
	 * @return string
	 */
	public function get_rms_url(): string {
		if ( defined( 'WC_SHIPPERHQ_RMS_URL' ) ) {
			return WC_SHIPPERHQ_RMS_URL;
		}

		return $this->is_sandbox() ? self::RMS_SANDBOX_URL : self::RMS_LIVE_URL;
	}

	/**
	 * @return string
	 */
	public function get_ovs_url(): string {
		if ( defined( 'WC_SHIPPERHQ_OVS_URL' ) ) {
			return WC_SHIPPERHQ_OVS_URL;
		}

		return $this->is_sandbox() ? self::OVS_SANDBOX_URL : self::OVS_LIVE_URL;
	}

	/**
	 * @return string
	 */
	public function get_bundle_url(): string {
		if ( defined( 'WC_SHIPPERHQ_OVS_BUNDLE_URL' ) ) {
			return WC_SHIPPERHQ_OVS_BUNDLE_URL;
		}

		return $this->is_sandbox() ? self::BUNDLE_DEV_URL : self::BUNDLE_LIVE_URL;
	}

	/**
	 * @return string 'LIVE' or 'TEST'
	 */
	public function get_scope(): string {
		return $this->is_sandbox() ? 'TEST' : 'LIVE';
	}

	/**
	 * @return bool
	 */
	public function is_sandbox(): bool {
		$settings     = get_option( 'woocommerce_shipperhq_settings', array() );
		$sandbox_mode = isset( $settings['sandbox_mode'] ) ? $settings['sandbox_mode'] : 'no';

		return 'yes' === $sandbox_mode;
	}
}
