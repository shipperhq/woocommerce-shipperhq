<?php
/*
 * ShipperHQ
 *
 * @category ShipperHQ
 * @package woocommerce-shipperhq
 * @copyright Copyright (c) 2025 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */

/**
 * Embeds the OVS (Order View Server) React client on the WooCommerce admin
 * order detail page to display advanced shipment details for ShipperHQ orders.
 *
 * Authenticates via a JWT secret token obtained from RMS, loads the OVS client
 * JS bundle, and lazily initializes the order view component on button click.
 */
class ShipperHQ_AdvancedShipmentDetails {

	/** @var ShipperHQ_OrderHelper */
	private $orderHelper;

	/** @var ShipperHQ_SecretToken_Helper */
	private $tokenHelper;

	/** @var ShipperHQ_OVS_UrlResolver */
	private $urlResolver;

	/**
	 * @param ShipperHQ_OrderHelper|null        $orderHelper
	 * @param ShipperHQ_SecretToken_Helper|null  $tokenHelper
	 * @param ShipperHQ_OVS_UrlResolver|null     $urlResolver
	 */
	public function __construct( $orderHelper = null, $tokenHelper = null, $urlResolver = null ) {
		if ( null === $orderHelper ) {
			if ( ! class_exists( 'ShipperHQ_OrderHelper' ) ) {
				require_once( plugin_dir_path( __FILE__ ) . '../helper/OrderHelper.php' );
			}
			$orderHelper = new ShipperHQ_OrderHelper();
		}

		$this->orderHelper = $orderHelper;
		$this->tokenHelper = $tokenHelper ?: new ShipperHQ_SecretToken_Helper();
		$this->urlResolver = $urlResolver ?: new ShipperHQ_OVS_UrlResolver();

		add_action( 'woocommerce_admin_order_data_after_shipping_address', array( $this, 'display_shipment_details_link' ), 5 );
	}

	/**
	 * Display "View Shipment Details" button and OVS iframe on the order detail page.
	 *
	 * @param WC_Order $order
	 */
	public function display_shipment_details_link( $order ) {
		if ( ! $this->is_shipperhq_order( $order ) ) {
			return;
		}

		$token = $this->tokenHelper->get_token();
		if ( ! $token ) {
			return;
		}

		$this->render_iframe( $order, $token );
	}

	/**
	 * Check if an order used a ShipperHQ shipping method.
	 *
	 * @param WC_Order $order
	 *
	 * @return bool
	 */
	private function is_shipperhq_order( $order ) {
		$this->orderHelper->set_order( $order );
		$carrier_type = $this->orderHelper->extract_shipping_meta_data_by_key( 'carrier_type' );
		if ( ! empty( $carrier_type ) ) {
			return true;
		}
		$carrier_code = $this->orderHelper->extract_shipping_meta_data_by_key( 'carrier_code' );

		return ! empty( $carrier_code );
	}

	/**
	 * Render iframe-based OVS client in a slide-in drawer with full CSS isolation.
	 *
	 * Builds a self-contained HTML document in the iframe srcdoc attribute that
	 * loads the OVS bundle and initializes the React app. The iframe is embedded
	 * in a right-side drawer panel that slides in on button click and can be closed
	 * via X button, backdrop click, or Escape key.
	 *
	 * DOMAIN: Provides CSS isolation so OVS styles don't conflict with WP admin
	 * CROSS-STACK: Embeds OVS React client via iframe in drawer UI pattern
	 *
	 * @param WC_Order $order
	 * @param string   $token
	 */
	private function render_iframe( $order, $token ) {
		$config = array(
			'endpoint'    => $this->urlResolver->get_ovs_url(),
			'secretToken' => $token,
			'scope'       => $this->urlResolver->get_scope(),
			'currency'    => $order->get_currency(),
		);

		$bundle_url   = $this->urlResolver->get_bundle_url();
		$order_number = esc_js( $order->get_order_number() );
		$config_json  = wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );

		// Build self-contained HTML document for iframe srcdoc.
		// srcdoc iframes have origin "null", so we use '*' for postMessage
		// and validate via event.source on the parent side instead.
		$iframe_html = '<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<style>
		body { margin: 0; }
		#shq-ov { overflow: hidden; }
	</style>
</head>
<body>
	<div id="shq-ov"></div>
	<script src="' . esc_attr( $bundle_url ) . '"></script>
	<script>
	(function() {
		var config = ' . $config_json . ';
		var orderNumber = \'' . $order_number . '\';
		var container = document.getElementById(\'shq-ov\');

		function notifyParentHeight() {
			parent.postMessage({
				type: \'shq-ov-resize\',
				height: document.body.scrollHeight
			}, \'*\');
		}

		function initOrderView() {
			if (window.shqOrderView && window.shqOrderView.SHQRenderOrderView) {
				window.shqOrderView.SHQRenderOrderView(container, orderNumber, config);

				var resizeObserver = new ResizeObserver(function() {
					notifyParentHeight();
				});
				resizeObserver.observe(container);
			} else {
				container.innerHTML = \'<p>Loading shipment details...</p>\';
				setTimeout(initOrderView, 200);
			}
		}

		initOrderView();
	})();
	</script>
</body>
</html>';

		?>
		<div class="shq-shipment-details-wrapper">
			<button type="button" id="shq-shipment-details-btn" class="button button-secondary">
				<?php esc_html_e( 'View Shipment Details', 'woocommerce-shipperhq' ); ?>
			</button>
		</div>
		<style>
			.shq-shipment-details-wrapper {
				margin-top: 12px;
			}
			.shq-drawer-backdrop {
				position: fixed;
				inset: 0;
				background: rgba(0,0,0,0.5);
				z-index: 100000;
				display: none;
			}
			.shq-drawer-backdrop.open {
				display: block;
			}
			.shq-drawer-panel {
				position: fixed;
				top: 0;
				right: 0;
				bottom: 0;
				width: 60%;
				max-width: 900px;
				min-width: 400px;
				background: #fff;
				transform: translateX(100%);
				transition: transform 0.3s ease;
				z-index: 100001;
				display: flex;
				flex-direction: column;
			}
			.shq-drawer-backdrop.open .shq-drawer-panel {
				transform: translateX(0);
			}
			.shq-drawer-header {
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 12px 16px;
				border-bottom: 1px solid #ddd;
			}
			.shq-drawer-title {
				margin: 0;
				font-size: 16px;
			}
			.shq-drawer-close {
				background: none;
				border: none;
				font-size: 24px;
				cursor: pointer;
				padding: 4px 8px;
			}
			.shq-drawer-body {
				flex: 1;
				overflow: auto;
			}
			#shq-ov-iframe {
				width: 100%;
				height: 100%;
				border: none;
			}
		</style>
		<div class="shq-drawer-backdrop" id="shq-drawer-backdrop">
			<div class="shq-drawer-panel">
				<div class="shq-drawer-header">
					<h2 class="shq-drawer-title"><?php esc_html_e( 'Shipment Details', 'woocommerce-shipperhq' ); ?></h2>
					<button type="button" class="shq-drawer-close" id="shq-drawer-close">&times;</button>
				</div>
				<div class="shq-drawer-body">
					<iframe id="shq-ov-iframe" srcdoc="<?php echo esc_attr( $iframe_html ); ?>" sandbox="allow-scripts allow-same-origin"></iframe>
				</div>
			</div>
		</div>
		<script>
		(function() {
			var btn = document.getElementById('shq-shipment-details-btn');
			var backdrop = document.getElementById('shq-drawer-backdrop');
			var closeBtn = document.getElementById('shq-drawer-close');

			if (!btn || !backdrop || !closeBtn) return;

			function handleEscape(event) {
				if (event.key === 'Escape') {
					closeDrawer();
				}
			}

			function openDrawer() {
				backdrop.classList.add('open');
				document.addEventListener('keydown', handleEscape);
			}

			function closeDrawer() {
				backdrop.classList.remove('open');
				document.removeEventListener('keydown', handleEscape);
			}

			btn.addEventListener('click', openDrawer);
			closeBtn.addEventListener('click', closeDrawer);

			backdrop.addEventListener('click', function(event) {
				if (event.target === backdrop) {
					closeDrawer();
				}
			});
		})();
		</script>
		<?php
	}
}
