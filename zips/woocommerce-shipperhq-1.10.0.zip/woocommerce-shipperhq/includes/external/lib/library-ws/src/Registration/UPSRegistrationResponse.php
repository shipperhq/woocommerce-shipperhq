<?php
/**
 * ShipperHQ
 *
 * @category ShipperHQ
 * @package ShipperHQ\WS
 * @copyright Copyright (c) 2019 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */

namespace ShipperHQ\WS\Registration;

use ShipperHQ\WS\AbstractWebServiceResponse;
use ShipperHQ\WS\WebServiceResponseInterface;

/**
 * Class UPSRegistrationResponse
 *
 * @package ShipperHQ\WS
 */
class UPSRegistrationResponse extends AbstractWebServiceResponse implements WebServiceResponseInterface
{

}
