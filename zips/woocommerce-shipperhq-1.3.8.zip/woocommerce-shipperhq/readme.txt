=== ShipperHQ for WooCommerce ===
Contributors: shipperhq
Tags: ecommerce, e-commerce, store, sales, sell, shipping, shipping rates, rating, rate management, cart, checkout, downloadable, downloads, shipperhq, shipper hq
Requires at least: 4.4
Tested up to: 5.2
Stable tag: 1.3.7
Requires PHP: 5.6
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Control the shipping rates and options you show in your WooCommerce cart. Live rates from 30+ carriers, LTL Freight and custom rates.

== Description ==

== The Future of eCommerce Shipping ==
ShipperHQ provides you with the ability to fully control and customize your shipping rates like never before. You define the carriers to use, the shipping methods that apply, and the unique rules of your own rate structure. We’ve created enough flexibility to easily generate and manipulate rates at the country, state, and even postcode level, with additional options for specific attributes like product or cart quantity, value, weight and dimensions. Basically, if it's a factor in shipping, it's fair game.

[youtube https://www.youtube.com/watch?v=2WymQcG1ofE]

== 30 Day Risk Free Trial ==
ShipperHQ comes with a [30 Day Risk Free Trial](https://shipperhq.com/signup) and subscriptions starting [as low as $50 a month](https://shipperhq.com/plans).

== Easily Manage All of Your Shipping Rates and Options from One Place ==

ShipperHQ is the most sophisticated rate calculation and rules engine in the world today. With ShipperHQ’s powerful features and tools you can offer the best possible rates for time and cost to ensure there is a perfect shipping option for your customers while allowing you to increase conversion, decrease cart abandonment, and win back old customers.

= Fully Customizable Rate Management =
- Use Carrier Rules to control what rates and options are shown and when.
- Define preferred carriers, shipping methods, advanced surcharges and discounts.
- Offer shipping rates and methods based on product, category, cart quantity, value, weight, dimensions and more.

= More Accurate Shipping Rates with Dimensional Shipping =
- Specify box sizes within orders with Dimensional Shipping.
- Specify dimensions of each of your boxes or use USPS Flat Rate Packages.
- Ship items separately or assign multiple products to the same box.
- Add additional packaging weight for boxes.
- Define combinations of products that can pack together.

= Multiple Carrier Support =
- Get live rates from more than 30 carriers including LTL Freight. Some of the major carriers we support include: UPS, USPS, FedEx, FedEx .- Smartpost, Australia Post, DHL and GSO along with LTL carriers.
- Get live rates from one or multiple major carriers within a single interface.
- Use base rates for each carrier or add your existing carrier accounts to automatically apply negotiated rates.

= Enterprise-grade Logistics =
- Get sophisticated shipping tools including LTL freight.
- Specify box sizes within orders with Dimensional Shipping.
- Offer Multi-Origin Shipping and Dropshipping to your customers.
	
= Centralized Shipping Analytics =
- Manage shipping activity across all carriers.
- Access key order information like time in transit, delivery estimates, average weight of products in customer carts and more.

== What Sets ShipperHQ Apart? ==

= Easy-to-Use Dashboard =
With all the options available for managing shipping rates, it would be easy for things to get a bit complex. That's why the ShipperHQ dashboard was developed specifically to manage shipping. Instead of managing shipping from the Wordpress admin panel, you'll be able to manage your shipping in a purpose-built dashboard. The right tool for the right job.

= Painless Commerce Platform Integration =
With ShipperHQ configuration management, carrier setup, and rate calculation logic all happen in the cloud. By installing a single plugin you can connect your WooCommerce store with the advanced capabilities in your ShipperHQ account.

= Broad Carrier Support =
ShipperHQ has built-in support for UPS, FedEx, USPS, and other major carriers. Use base rates or enter your account details to use your negotiated rates. Either way, you can rest easy knowing that the work of managing connections to your carriers of choice is handled by ShipperHQ. The world's most powerful shipping rate interface backed by a worldwide fleet of elite carriers, we feel like this makes for a winning combination.

= Work with our Shipping Experts =
ShipperHQ was built on the culmination of many years of shipping experience and we have serviced tens of thousands of merchants worldwide. Our team of eCommerce shipping experts are happy to help you get up and running in no time. With Consultation Services, Priority Support, and Configuration Services you have the option to work with us through set up or to leave the shipping to us so you can focus on running your business. Contact us for a quote on any of our additional services.

== Installation ==

Our [Help Docs](http://docs.shipperhq.com) provide detailed instructions on [how to install the ShipperHQ WooCommerce Plugin](https://docs.shipperhq.com/install-woocommerce-plugin) and more!


== Frequently Asked Questions ==

= What happens after 30 days? =
If you haven't set up billing your account will be deactivated but you'll still have access to log in and set up billing to re-enable your account. Your settings will be saved for at least 30 days if you wish to re-activate. After 30 days of inactivity your account may be deleted. You can reactivate your account whenever you'd like before that point by logging in and setting up billing.

= How long are your contracts? =
On all standard plans, you'll have the option to cancel at any time. We don't provide refunds at cancellation, but your account will be active until the end of the period you've paid for. Enterprise plan contracts are written on a individual basis.


== Screenshots ==

1. ShipperHQ at work in your WooCommerce Cart.
2. ShipperHQ at work in your WooCommerce Checkout.
3. Origins in ShipperHQ
4. Carriers in ShipperHQ
5. Carriers Rules in ShipperHQ
6. Zones in ShipperHQ
7. Shipping Groups in ShipperHQ
8. Filters in ShipperHQ

== Changelog ==

= 1.3.7 - 2019-05-31
SHQ18-2022 Added hs code to shipping attributes
= 1.3.6 - 2019-01-25
SHQ18-1204 Make methods around getting inventory status public so they can be extended
= 1.3.5 - 2018-12-05
SHQ18-1158 Prevent calling ShipperHQ API when credentials are missing
= 1.3.4 - 2018-11-27
SHQ18-1079 Support for WooCommerce product add on module
= 1.3.3 - 2018-10-31
SHQ18-1006 Fix issue with ship separately and must ship freight checlboxes
= 1.2.11 - 2017-10-11
SHQ16-2339 remove use of deprecated function
= 1.2.10 - 2017-10-09
Update to readme.txt for WordPress store release
= 1.2.9 - 2017-08-15
SHQ16-2216 modified headers and function name after review
= 1.2.8 - 2017-08-09
SHQ16-2202 Support for 2.6 and below version no parent_id


[See CHANGELOG-PUBLIC.md for all versions](https://plugins.svn.wordpress.org/woo-shipperhq/trunk/CHANGELOG-PUBLIC.md)

== Upgrade Notice ==

= 1.3.5 =
Update to this version to prevent calls to ShipperHQ API unnecessarily
= 1.3.3 =
Update to this version to ensure must ship freight and ship separately checkboxes work
= 1.2.11 =
Update to this version to ensure compatibility with WooCommerce v3.0+
= 1.2.10 =
This version includes changes to the listing text
= 1.2.9 =
This version was submitted to WordPress for public release

