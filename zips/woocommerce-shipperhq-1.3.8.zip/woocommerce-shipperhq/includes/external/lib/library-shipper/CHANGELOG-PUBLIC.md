## 20.3.3
SHQ16-2392 added comments and refactored unit tests, added tests for calendarDetails default date, M2-52 remove dependency on debug setting to enable logging


## 20.7.0 (2018-06-21)
Bring releases and versioning back in line


## 20.8.0 (2018-06-25)
SHQ18-277 refactor save selections functions to reuse selection object


## 20.9.0 (2018-08-02)
SHQ18-155 support map and location details for in store pickup


## 20.10.0 (2019-03-14)
SHQ18-1613 Display actual method chosen by rate shopping in admin panel


## 20.10.1 (2019-04-29)
SHQ18-1675 Added support for the new TimeSlotBreakDown field


