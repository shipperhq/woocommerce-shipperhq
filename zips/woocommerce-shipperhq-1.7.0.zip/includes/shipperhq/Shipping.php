<?php
/*
 * ShipperHQ
 *
 * @category ShipperHQ
 * @package woocommerce-shipperhq
 * @copyright Copyright (c) 2020 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ShipperHQ_Shipping
 * Handles shipping integration with ShipperHQ
 */
class ShipperHQ_Shipping {
	/**
	 * Constructor - register hooks
	 */
	public function __construct() {
		add_action( 'woocommerce_shipping_methods', array( $this, 'add_shipperhq_methods' ) );
		// Initialize shipping method class
		add_action( 'woocommerce_shipping_init', array( $this, 'init_shipping_file' ) );
		// Setup placeOrder handler
		add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'handle_wc_checkout_update_order_meta' ) );
		// Add CSS selectors to shipping methods and split estimated delivery dates into new line
		add_action( 'woocommerce_after_shipping_rate', array( $this, 'checkout_shipping_add_css' ), 10, 2 );
		// Adjust the method name to add back in the estimated delivery date info if required
		add_action( 'woocommerce_checkout_create_order_shipping_item',
			array( $this, 'checkout_shipping_adjust_method_name' ), 10, 4 );
		// Add CSS to shipping methods
		add_action( 'wp_enqueue_scripts', array( $this, 'add_shipperhq_styles' ) );
	}

	/**
	 * Adds the CSS for the cart and checkout page
	 * @return void
	 */
	public function add_shipperhq_styles() {
		wp_enqueue_style(
			'shipperhq_styles',
			plugins_url( 'assets/css/shipperhq-styles.css', WC_SHIPPERHQ_ROOT_FILE ),
			array(),
			WooCommerce_ShipperHQ::get_instance()->version
		);
	}

	/**
	 * RIV-1247 Sets the shipping method name to method name with delivery message appended.
	 * Ensures backward compatibility
	 *
	 * @param WC_Order_Item_Shipping $item        The shipping item.
	 * @param int                    $package_key The package key.
	 * @param array                  $package     The package data.
	 * @param WC_Order               $order       The order object.
	 *
	 * @return void
	 * @throws WC_Data_Exception
	 */
	public function checkout_shipping_adjust_method_name( $item, $package_key, $package, $order ) {
		$method_description = $item->get_meta( "method_description" );
		if ( ! empty( $method_description ) ) {
			$item->set_method_title( $item->get_method_title() . ' ' . __( $method_description, 'woocommerce-shipperhq' ) );
		}
	}

	/**
	 * RIV-1247 Adds CSS class to method description which holds the estimated delivery date if present
	 *
	 * @param WC_Shipping_Method $method The shipping method.
	 * @param int                $index  The index.
	 *
	 * @return void
	 */
	public function checkout_shipping_add_css( $method, $index ) {
		if ( $method->get_method_id() == "shipperhq" ) {
			$meta_data = $method->get_meta_data();
			if ( isset( $meta_data['method_description'] ) && ! empty( $meta_data['method_description'] ) ) {
				echo '<span id="shipperhq-method-description" class="shipperhq-method-description">' .
				     esc_html( $meta_data['method_description'] ) .
				     '</span>';
			}
		}
	}

	public function add_shipperhq_methods( $methods ) {
		$methods[] = 'ShipperHQ_Shipping_Method';

		return $methods;
	}

	public function init_shipping_file() {
		/**
		 * Shipping method class
		 */
		require_once plugin_dir_path( __FILE__ ) . '/ShippingMethod.php';
	}

	/**
	 * Handle order creation - potentially create shipping listing
	 *
	 * @param int $order_id The order ID.
	 *
	 * @return void
	 */
	public function handle_wc_checkout_update_order_meta( $order_id ) {
		require_once plugin_dir_path( __FILE__ ) . '/ListingManager.php';
		require_once plugin_dir_path( __FILE__ ) . '/helper/OrderHelper.php';
		$order_helper            = new ShipperHQ_OrderHelper( $order_id );
		$settings                = get_option( 'woocommerce_shipperhq_settings', array() );
		$auto_listing_is_enabled = isset( $settings['create_listing'] ) && 'AUTO' === $settings['create_listing'];
		// SHQ18-2977 - Check if we even need to create a listing before wasting further effort
		if ( $auto_listing_is_enabled && $order_helper->shipping_method_is_uship() ) {
			$listing_manager = new ShipperHQ_Listing_Manager();
			$listing_manager->create_listing_for_order( $order_id );
		}
	}
}
