<?php
/*
 * ShipperHQ
 *
 * @category ShipperHQ
 * @package woocommerce-shipperhq
 * @copyright Copyright (c) 2020 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */

use ShipperHQ\Lib\Helper\Date;
use ShipperHQ\Lib\Rate\ConfigSettings;
use ShipperHQ\Lib\Rate\Helper;
use ShipperHQ\WS\Client\WebServiceClient;
use ShipperHQ\WS\Rate\Request\RateRequest;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( class_exists( 'ShipperHQ_Shipping_Method' ) ) {
	return;
} // Exit if class already exists
class ShipperHQ_Shipping_Method extends WC_Shipping_Method {
	/**
	 * ShipperHQ helper
	 * @var Helper
	 */
	protected $_shipperHQHelper;
	/**
	 * Web service helper
	 * @var ShipperHQ_RestHelper
	 */
	protected $_wsHelper;
	/**
	 * Whether logging is enabled
	 * @var bool
	 */
	public static $log_enabled = FALSE;
	/**
	 * Logger instance
	 * @var WC_Logger|false
	 */
	public static $log = FALSE;
	/**
	 * Sandbox mode setting
	 * @var string
	 */
	protected $sandboxMode;
	/**
	 * Settings array
	 * @var array
	 */
	public $settings = [];
	/**
	 * Debug mode
	 * @var bool|string
	 */
	protected $debug;

	public function __construct() {
		$this->id                 = 'shipperhq';
		$this->method_title       = __( 'ShipperHQ', 'woocommerce' );
		$this->method_description = __( '
                    ShipperHQ Official Plugin - The most advanced eCommerce shipping management platform in the world. <br /><br />
                    For documentation and examples, please see the <a href="http://docs.shipperhq.com" target="_blank">ShipperHQ knowledge base</a>.<br /><br />
                    If you have questions about ShipperHQ or need support, visit <a href="http://www.ShipperHQ.com" target="_blank">http://www.ShipperHQ.com</a>.<br />
 				', 'woocommerce' );
		// Load the settings.
		$this->init_form_fields();
		$this->include_libs();
		// $this->validate_settings();
		$dateHelper             = new Date;
		$this->_shipperHQHelper = new Helper( $dateHelper );
		$this->_wsHelper        = new ShipperHQ_RestHelper( $this->get_option( 'sandbox_mode' ) );
		// Define user set variables
		$this->enabled     = $this->get_option( 'enabled' );
		$this->title       = $this->get_option( 'title' );
		$this->sandboxMode = $this->get_option( 'sandbox_mode' );
		$this->debug       = 'yes' === $this->get_option( 'debug', 'no' );
		self::$log_enabled = $this->debug;
		add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	/**
	 * Process the settings
	 * @return bool
	 */
	public function process_admin_options() {
		$result = parent::process_admin_options();
		// TODO: Refactor me
		$api_key         = $_REQUEST['woocommerce_shipperhq_api_key'];
		$auth_code       = $_REQUEST['woocommerce_shipperhq_authentication_code'];
		$restHelper      = new ShipperHQ_RestHelper( $_REQUEST['debug'] );
		$endpoint        = $restHelper->getAttributeGatewayUrl();
		$credentials     = new ShipperHQ\WS\Shared\Credentials( $api_key, $auth_code );
		$siteDetails     = ( new ShipperHQ_Mapper() )->getSiteDetails();
		$request         = [
			'siteDetails' => $siteDetails,
			'credentials' => $credentials
		];
		$args            = [
			'headers' => [ 'Content-Type' => 'application/json' ],
			'body'    => json_encode( $request ),
		];
		$response        = wp_remote_post( $endpoint, $args );
		$responseBodyStr = wp_remote_retrieve_body( $response ) ?: "{}";
		$responseBody    = json_decode( $responseBodyStr, TRUE );
		// Add null/index checks for PHP 8.4 compatibility
		if ( isset( $responseBody['attributeTypes'] ) && is_array( $responseBody['attributeTypes'] ) ) {
			$listingData                      = array_filter( $responseBody['attributeTypes'], function ( $attr ) {
				return isset( $attr['code'] ) && $attr['code'] === 'carrier_listing_type';
			} );
			$firstItem                        = reset( $listingData );
			$listingAttrs                     = $firstItem['attributes'] ?? [];
			$listingSetting                   = array_reduce( $listingAttrs, function ( $carry, $item ) {
				if ( ( $carry === 'AUTO' ) || ( isset( $item['createListing'] ) && $item['createListing'] === 'AUTO' ) ) {
					return 'AUTO';
				} elseif ( ( $carry === 'MANUAL' ) || ( isset( $item['createListing'] ) && $item['createListing'] === 'MANUAL' ) ) {
					return 'MANUAL';
				}

				return $carry;
			}, 'NONE' );
			$this->settings['create_listing'] = $listingSetting;
		}
		update_option( 'woocommerce_shipperhq_settings', $this->settings );

		return $result;
	}

	/**
	 * Include the required libraries
	 * @return void
	 */
	private function include_libs() {
		$shq_dir = plugin_dir_path( __FILE__ );
		require_once( $shq_dir . 'helper/Mapper.php' );
		require_once( $shq_dir . 'helper/RestHelper.php' );
		require_once( $shq_dir . '/../external/lib/library-shipper/src/Rate/ConfigSettings.php' );
		require_once( $shq_dir . '/../external/lib/library-shipper/src/Rate/Helper.php' );
		require_once( $shq_dir . '/../external/lib/library-shipper/src/Helper/Date.php' );
		require_once( $shq_dir . '/../external/lib/library-ws/src/Shared/BasicAddress.php' );
		require_once( $shq_dir . '/../external/lib/library-ws/src/Shared/Address.php' );
		require_once( $shq_dir . '/../external/lib/library-ws/src/Shared/Credentials.php' );
		require_once( $shq_dir . '/../external/lib/library-ws/src/Shared/SiteDetails.php' );
		require_once( $shq_dir . '/../external/lib/library-ws/src/Rate/Request/Checkout/Item.php' );
		require_once( $shq_dir . '/../external/lib/library-ws/src/Rate/Request/Checkout/Cart.php' );
		require_once( $shq_dir . '/../external/lib/library-ws/src/WebServiceRequestInterface.php' );
		require_once( $shq_dir . '/../external/lib/library-ws/src/AbstractWebServiceRequest.php' );
		require_once( $shq_dir . '/../external/lib/library-ws/src/Client/WebServiceClient.php' );
		require_once( $shq_dir . '/../external/lib/library-ws/src/Rate/Request/RateRequest.php' );
		require_once( $shq_dir . '/../external/lib/library-ws/src/Rate/Request/CustomerDetails.php' );
	}

	/**
	 * Calculate shipping rates
	 *
	 * @param array $package The package data.
	 *
	 * @return void
	 */
	public function calculate_shipping( $package = array() ) {
		// let's call out to ShipperHQ
		$init_val = microtime( TRUE );
		// create the request
		$shq_request = $this->create_request( $package );
		if ( NULL === $shq_request ) {
			self::log( 'ShipperHQ_Shipper Couldn\'t create request. Possibly missing API key or Authentication Code' . ' or required address fields are missing' );

			return;
		}
		// send the request
		$shq_results = $this->send_request( $shq_request );
		// parse results
		$this->parse_shipping_results( $shq_request, $shq_results );
		$elapsed = microtime( TRUE ) - $init_val;
		self::log( 'Shipperhq_Shipper Long lapse: ' . $elapsed );
	}

	/**
	 * Check if the address is valid
	 *
	 * @param $package
	 *
	 * @return bool
	 */
	private function is_valid_address( $package ): bool {
		$valid_address           = TRUE;
		$desintationCountry      = $package['destination']['country'] ?? '';
		$destinationState        = $package['destination']['state'] ?? '';
		$destinationPostcode     = $package['destination']['postcode'] ?? '';
		$requiredFieldsByCountry = wc()->countries->get_country_locale();
		// Must have a country specified for us to get rates
		if ( empty( $desintationCountry ) ) {
			$valid_address = FALSE;
		} elseif ( $this->get_option( 'ignore_empty_zip' ) === "yes" && isset( $requiredFieldsByCountry[ $desintationCountry ] ) ) {

			$requiredFields = $requiredFieldsByCountry[ $desintationCountry ];
			// Weirdly, the field required is only present if the field is not required.
			// It's always set to false if present. Added belt and braces check in case it is set to true in future
			if ( isset( $requiredFields["state"] ) && ( ! isset( $requiredFields["state"]["required"] ) || ( $requiredFields["state"]["required"] ) ) && empty( $destinationState ) ) {
				$valid_address = FALSE;
			} else if ( isset( $requiredFields["postcode"] ) && ( ! isset( $requiredFields["postcode"]["required"] ) || ( $requiredFields["postcode"]["required"] ) ) && empty( $destinationPostcode ) ) {
				$valid_address = FALSE;
			}
		}

		return $valid_address;
	}

	/**
	 * Create the request to send ShipperHQ
	 *
	 * @param array $package The package data.
	 *
	 * @return RateRequest|null
	 */
	private function create_request( $package ) {
		if ( ! $this->is_valid_address( $package ) ) {
			return NULL;
		}
		$shq_api = new ShipperHQ_Mapper();

		return $shq_api->create_request( $package );
	}

	/**
	 * Sends the JSON request
	 *
	 * @param RateRequest $shq_request The request to send.
	 *
	 * @return array|null
	 */
	private function send_request( $shq_request ) {
		$timeout            = '30';
		$init_val           = microtime( TRUE );
		$web_service_client = new WebServiceClient();
		$result_set         = $web_service_client->sendAndReceiveWp( $shq_request, $this->_wsHelper->getRateGatewayUrl(), $timeout );
		$elapsed            = microtime( TRUE ) - $init_val;
		self::log( 'Shipperhq_Shipper Short lapse: ' . $elapsed );
		if ( ! $result_set['result'] ) {
			return NULL;
		}
		self::log( 'Rate request and result: ' );
		self::log( $result_set['debug'] );

		return $result_set['result'];
	}

	/**
	 * Returns a list of origins for this shipment
	 *
	 * @param array $rate_details Rate details
	 *
	 * @return string
	 */
	private function get_origin_from_cg( $rate_details ) {
		if ( isset( $rate_details['carriergroup_detail'] ) ) {
			$cg_detail = $rate_details['carriergroup_detail'];
			if ( ! empty( $cg_detail ) && isset( $cg_detail[0] ) && is_array( $cg_detail[0] ) ) {
				$origins = [];
				foreach ( $cg_detail as $detail ) {
					if ( isset( $detail['name'] ) ) {
						$origins[] = $detail['name'];
					}
				}

				return implode( ', ', array_unique( $origins ) );
			} elseif ( isset( $cg_detail['name'] ) ) {
				return $cg_detail['name'];
			}
		}

		return '';
	}

	/**
	 * Returns a string containing the method title exclusive of any dates
	 *
	 * @param array $rate_details Rate details
	 *
	 * @return string
	 */
	private function get_method_label( $rate_details ): string {
		if ( empty( $rate_details['method_description'] ) ) {
			return $rate_details['method_title'];
		}

		return str_replace( $rate_details['method_description'], '', $rate_details['method_title'] );
	}

	/**
	 * Parse the results so can be output on frontend
	 *
	 * @param $shq_request
	 * @param $shipper_response
	 */
	private function parse_shipping_results( $shq_request, $shipper_response ) {
		if ( empty( $shipper_response ) ) {
			self::log( 'Warning: Empty response from ShipperHQ' );

			return;
		}
		$debugRequest     = $shq_request;
		$debugData        = [ 'request' => $debugRequest, 'response' => $shipper_response ];
		$shipper_response = $this->_shipperHQHelper->object_to_array( $shipper_response );
		if ( isset( $shipper_response['carrierGroups'] ) ) {
			// SHQ16-2350
			$transactionId = $this->_shipperHQHelper->extractTransactionId( $shipper_response );
			$carrierRates  = $this->processRatesResponse( $shipper_response, $transactionId );
		} else {
			$carrierRates = [];
		}
		if ( count( $carrierRates ) == 0 ) {
			self::log( 'WARNING: ShipperHQ did not return any carrier rates' );
			self::log( $debugData );

			return;
		}
		foreach ( $carrierRates as $carrierRate ) {
			if ( isset( $carrierRate['error'] ) ) {
				$errorMsg = isset( $carrierRate['error']['internalErrorMessage'] ) ? $carrierRate['error']['internalErrorMessage'] : 'Unknown error';
				self::log( 'ShipperHQ ' . ( isset( $carrierRate['code'] ) ? $carrierRate['code'] : 'Unknown code' ) . ' ' . ( isset( $carrierRate['title'] ) ? $carrierRate['title'] : 'Unknown title' ) . ' returned error ' . $errorMsg );
				continue;
			}
			if ( ! isset( $carrierRate['rates'] ) ) {
				self::log( 'WARNING: ShipperHQ did not return any rates for ' . ( isset( $carrierRate['code'] ) ? $carrierRate['code'] : 'Unknown code' ) . ' ' . ( isset( $carrierRate['title'] ) ? $carrierRate['title'] : 'Unknown title' ) );
				continue;
			}
			foreach ( $carrierRate['rates'] as $rateDetails ) {
				$rate = array(
					'id'        => $rateDetails['carrier_id'] . "_" . $rateDetails['methodcode'],
					// RIV-1247 Remove the estimated date text from method title
					'label'     => $this->get_method_label( $rateDetails ),
					'cost'      => $rateDetails['price'],
					'meta_data' => [
						'carrier_code'        => $carrierRate['code'],
						'carrier_id'          => $rateDetails['carrier_id'],
						'method_code'         => $rateDetails['methodcode'],
						'carrier_type'        => $rateDetails['carrier_type'],
						'origin'              => $this->get_origin_from_cg( $rateDetails ),
						'carriergroup_detail' => $rateDetails['carriergroup_detail'],
						'method_description'  => $rateDetails['method_description'] ?? "",
					]
				);
				if ( isset( $rateDetails['carriergroup_detail']['rate_cost'] ) && $rateDetails['carriergroup_detail']['rate_cost'] ) {
					$rate['meta_data']['nyp_amount'] = $rateDetails['carriergroup_detail']['rate_cost'];
				}
				$this->add_rate( $rate );
			}
		}
	}

	/**
	 * Build array of carrier group details for extractShipperHQMergedRates()
	 *
	 * @param $carrierGroups
	 * @param $transactionId
	 * @param $configSettings
	 *
	 * @return array
	 */
	protected function populateSplitCarrierGroupDetail( $carrierGroups, $transactionId, $configSettings ) {
		$splitCarrierGroupDetail = [];
		foreach ( $carrierGroups as $carrierGroup ) {
			$carrierGroupDetail = $this->_shipperHQHelper->extractCarriergroupDetail( $carrierGroup, $transactionId, $configSettings );
			foreach ( $carrierGroup['carrierRates'] as $carrierRate ) {
				$carrierCode = $carrierRate['carrierCode'];
				foreach ( $carrierRate['rates'] as $rate ) {
					$methodCode                                                                                      = $rate['code'];
					$splitCarrierGroupDetail[ $carrierGroupDetail["carrierGroupId"] ][ $carrierCode ][ $methodCode ] = $carrierGroupDetail;
				}
			}
		}

		return $splitCarrierGroupDetail;
	}

	/**
	 * Build array of rates based on split or merged rates display
	 *
	 * @param $shipperResponse
	 * @param $transactionId
	 *
	 * @return array
	 */
	protected function processRatesResponse( $shipperResponse, $transactionId ) {
		$ratesArray              = [];
		$configSetttings         = $this->getConfigSettings();
		$splitCarrierGroupDetail = [];
		// if merged response lets take that
		if ( isset( $shipperResponse['mergedRateResponse'] ) ) {
			$splitCarrierGroupDetail = $this->populateSplitCarrierGroupDetail( $shipperResponse['carrierGroups'], $transactionId, $configSetttings );
			$mergedRatesArray        = [];
			foreach ( $shipperResponse['mergedRateResponse']['carrierRates'] as $carrierRate ) {
				$mergedResultWithRates = $this->_shipperHQHelper->extractShipperHQMergedRates( $carrierRate, $splitCarrierGroupDetail, $configSetttings, $transactionId );
				$mergedRatesArray[]    = $mergedResultWithRates;
			}
			$ratesArray = $mergedRatesArray;
		} else {
			$carrierGroups = $shipperResponse['carrierGroups'];
			foreach ( $carrierGroups as $carrierGroup ) {
				$carrierGroupDetail = $this->_shipperHQHelper->extractCarriergroupDetail( $carrierGroup, $transactionId, $configSetttings );
				// Pass off each carrier group to helper to decide best fit to process it.
				// Push result back into our array
				foreach ( $carrierGroup['carrierRates'] as $carrierRate ) {
					$carrierResultWithRates = $this->_shipperHQHelper->extractShipperHQRates( $carrierRate, $carrierGroupDetail, $configSetttings, $splitCarrierGroupDetail );
					$ratesArray[]           = $carrierResultWithRates;
				}
			}
		}

		return $ratesArray;
	}

	protected function getLocaleInGlobals() {
		return 'en-US';
	}

	/**
	 * Retrieve debug configuration
	 * @return boolean
	 */
	public function isTransactionIdEnabled() {
		//        if (self::$showTransId == NULL) {
		//            self::$showTransId = $this->getConfigValue('carriers/shipper/display_transaction');
		//        }
		return FALSE;
	}

	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'             => array(
				'title'   => __( 'Enable/Disable', 'woocommerce' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable ShipperHQ', 'woocommerce' ),
				'default' => 'yes'
			),
			'title'               => array(
				'title'       => __( 'Main Shipping Carrier Title', 'woocommerce' ),
				'type'        => 'text',
				'description' => __( 'Name of the main shipping carrier, also used for carrier title if no rates can be
                        found. This is updated dynamically from ShipperHQ', 'woocommerce' ),
				'default'     => __( 'Shipping Rates', 'woocommerce' ),
			),
			'api_key'             => array(
				'title'       => __( 'API Key', 'woocommerce' ),
				'type'        => 'text',
				'description' => __( 'Obtain from under Websites in the ShipperHQ Dashboard' ),
			),
			'authentication_code' => array(
				'title'       => __( 'Authentication Code', 'woocommerce' ),
				'type'        => 'password',
				'description' => __( 'Obtain from under Websites in the ShipperHQ Dashboard' ),
			),
			'hide_notify'         => array(
				'title'       => __( 'Carrier Notifications at Checkout', 'woocommerce' ),
				'label'       => __( 'Hide Notifications', 'woocommerce' ),
				'type'        => 'checkbox',
				'description' => __( 'Carriers may include notifications when their live rates have been modified.' ),
				'default'     => 'no'
			),
			'ignore_empty_zip'    => array(
				'title'       => __( 'Require Meaningful Address To Request Rates', 'woocommerce' ),
				'type'        => 'checkbox',
				'description' => __( 'Only request shipping rates from ShipperHQ if all of the required address fields in checkout are populated.
					This helps to lower the number of API requests' ),
				'label'       => __( 'Will reduce number of requests made to ShipperHQ', 'woocommerce' ),
				'desc_tip'    => TRUE,
				'default'     => 'yes'
			),
			'sandbox_mode'        => array(
				'title'   => __( 'Use Sandbox', 'woocommerce' ),
				'type'    => 'checkbox',
				'label'   => __( 'Please leave Unchecked!', 'woocommerce' ),
				'default' => 'no'
			),
			'ws_timeout'          => array(
				'title'       => __( 'Connection Timeout (seconds)', 'woocommerce' ),
				'type'        => 'text',
				'description' => __( '', 'woocommerce' ),
				'default'     => __( '30', 'woocommerce' ),
			),
			'debug'               => array(
				'title'       => __( 'Debug Log', 'woocommerce' ),
				'type'        => 'checkbox',
				'label'       => __( 'Enable logging', 'woocommerce' ),
				'default'     => 'no',
				'description' => sprintf( __( 'Log ShipperHQ shipping rate requests and debug information' ) )
			),
		);
	}

	/**
	 * Check if the method is available for the given package
	 *
	 * @param array $package
	 *
	 * @return bool
	 */
	public function is_available( $package ) {
		//TODO
		return parent::is_available( $package );
	}

	/**
	 * Logging method
	 *
	 * @param string $message
	 */
	public static function log( $message ) {
		if ( self::$log_enabled ) {
			if ( empty( self::$log ) ) {
				self::$log = new WC_Logger();
			}
			self::$log->add( 'ShipperHQ', print_r( $message, TRUE ) );
		}
	}

	/**
	 * Get the config settings for ShipperHQ
	 * @return ConfigSettings
	 */
	protected function getConfigSettings() {
		$configSetttings                       = new ConfigSettings( $this->get_option( 'hide_notify' ), $this->isTransactionIdEnabled(), $this->getLocaleInGlobals(), "shipperhq", $this->get_option( 'title' ), wc_timezone_string() );
		$configSetttings->hideNotifications    = $this->get_option( 'hide_notify' );
		$configSetttings->transactionIdEnabled = $this->isTransactionIdEnabled();
		$configSetttings->locale               = $this->getLocaleInGlobals();

		return $configSetttings;
	}
}
