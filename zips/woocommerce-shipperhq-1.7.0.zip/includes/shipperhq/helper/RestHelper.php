<?php
/*
 * ShipperHQ
 *
 * @category ShipperHQ
 * @package woocommerce-shipperhq
 * @copyright Copyright (c) 2020 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */

class ShipperHQ_RestHelper {
	private $_testUrl = "http://www.localhost.com:8080/shipperhq-ws/v1/";
	private $_liveUrl = "https://api.shipperhq.com/v1/";
	private $_sandboxMode;
	/**
	 * @var int|null
	 */
	private static $wsTimeout = NULL;

	public function __construct( $sandboxMode ) {
		$this->_sandboxMode = $sandboxMode;
	}

	/**
	 * Returns url to use - live if present, otherwise dev
	 * @return string
	 */
	protected function _getGatewayUrl() {
		return $this->_sandboxMode == "yes" ? $this->_testUrl : $this->_liveUrl;
	}

	/**
	 * Retrieve url for getting allowed methods
	 * @return string
	 */
	public function getAllowedMethodGatewayUrl(): string {
		return $this->_getGatewayUrl() . 'allowed_methods';
	}

	/**
	 * Retrieve url for getting shipping rates
	 * @return string
	 */
	public function getRateGatewayUrl() {
		return $this->_getGatewayUrl() . 'rates';
	}

	/**
	 * Retrieve url for retrieving attributes
	 * @return string
	 */
	public function getAttributeGatewayUrl(): string {
		return $this->_getGatewayUrl() . 'attributes/get';
	}

	/**
	 * Retrieve url for checking if attributes are synchronized
	 * @return string
	 */
	public function getCheckSynchronizedUrl() {
		return $this->_getGatewayUrl() . 'attributes/check';
	}
}
