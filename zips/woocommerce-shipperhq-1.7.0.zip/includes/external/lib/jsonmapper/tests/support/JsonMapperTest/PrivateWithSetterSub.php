<?php
class JsonMapperTest_PrivateWithSetterSub extends JsonMapperTest_PrivateWithSetter
{
}
?>
