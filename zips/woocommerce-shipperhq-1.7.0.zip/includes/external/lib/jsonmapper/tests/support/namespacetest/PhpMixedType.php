<?php

declare(strict_types=1);

namespace namespacetest;

class PhpMixedType
{
    public mixed $data;
}
