<?php
class Fish extends Animal
{
}
