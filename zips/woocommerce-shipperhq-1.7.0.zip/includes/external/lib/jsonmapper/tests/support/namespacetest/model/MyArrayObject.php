<?php
namespace namespacetest\model;

class MyArrayObject extends \ArrayObject
{
}
?>
