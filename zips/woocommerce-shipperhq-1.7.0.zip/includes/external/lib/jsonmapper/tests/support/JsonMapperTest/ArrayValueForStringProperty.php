<?php
class JsonMapperTest_ArrayValueForStringProperty
{
	public string $value;
}
