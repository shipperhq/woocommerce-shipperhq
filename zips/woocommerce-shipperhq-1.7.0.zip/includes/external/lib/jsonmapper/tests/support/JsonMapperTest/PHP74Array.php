<?php

declare(strict_types=1);

class JsonMapperTest_PHP74Array
{
    public array $files;
}
