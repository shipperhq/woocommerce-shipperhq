# Change Log
All notable changes to this project will be documented in this file.
This project adheres to Semantic Versioning(http://semver.org/).

## 1.0.1
Initial Release

## 1.0.2
SHQ16-1355 Implemented merged rate support

## 1.0.3
Improving Build process

## 1.1.0
Improving Build process

## 1.1.1
Support for shipping attributes on product variants

## 1.1.2
SHQ16-1841 WooCommerce build changes

## 1.2.0
SHQ16-1933 add shipperhq_warehouse to the request

## 1.2.1
SHQ16-1935 child product qty should be 1 for configurable products

## 1.2.2
patch

## 1.2.3
SHQ16-2068 Fixed issues with directly accessing product data and function_exists calls

## 1.2.4
SHQ16-2068 Fixed issues with directly accessing product data

## 1.2.5
SHQ16-2068 support for versions below 2.6

## 1.2.6
SHQ16-2068 check for get_id function before using

## 1.2.7
SHQ16-2202 extract correct productId for parent and child of variations

## 1.2.8
SHQ16-2202 Support for 2.6 and below version no parent_id

## 1.2.9
SHQ16-2216 modified headers and function name after review
