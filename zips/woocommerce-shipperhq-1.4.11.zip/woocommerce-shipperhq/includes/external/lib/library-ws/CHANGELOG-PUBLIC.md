## 20.4.0 (2018-06-21)
Bring releases and versioning back in line


## 20.4.1 (2019-03-27)
SHQ18-1712 Dont send empty request to ShipperHQ


## 20.5.0 (2021-03-30)
RIV-443 Add placeorder support


## 20.6.0 (2021-12-21)
RIV-530 Support address for placeOrder request


## 20.7.0 (2022-05-13)
MNB-2430 M2.4.4 compatibility


