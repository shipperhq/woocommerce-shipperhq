<?php
if ( ! defined( 'ABSPATH' ) ) exit;


class ShipperHQ_Shipping {


    /**
     * Add the ShipperHQ Shipping Method
     */
    public function __construct() {
        
        add_action( 'woocommerce_shipping_methods', array( $this, 'add_shipperhq_methods' ) );
        

        // Initialize shipping method class
        add_action( 'woocommerce_shipping_init', array( $this, 'init_shipping_file' ) );

    }

    public function add_shipperhq_methods( $methods ) {
        $methods[] = 'ShipperHQ_Shipping_Method';
        return $methods;
    }

    public function init_shipping_file() {

        /**
         * Shipping method class
         */
        require_once plugin_dir_path( __FILE__ ) . '/ShippingMethod.php';

    }
    
}