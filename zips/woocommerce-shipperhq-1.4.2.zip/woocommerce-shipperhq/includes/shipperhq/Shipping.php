<?php
if (!defined('ABSPATH')) exit;


class ShipperHQ_Shipping
{


    /**
     * Add the ShipperHQ Shipping Method
     */
    public function __construct()
    {

        add_action('woocommerce_shipping_methods', array($this, 'add_shipperhq_methods'));

        // Initialize shipping method class
        add_action('woocommerce_shipping_init', array($this, 'init_shipping_file'));

        // Setup placeOrder handler
        add_action('woocommerce_checkout_update_order_meta', array($this, 'handle_wc_checkout_update_order_meta'));

    }

    public function add_shipperhq_methods($methods)
    {
        $methods[] = 'ShipperHQ_Shipping_Method';
        return $methods;
    }

    public function init_shipping_file()
    {

        /**
         * Shipping method class
         */
        require_once plugin_dir_path(__FILE__) . '/ShippingMethod.php';

    }

    public function handle_wc_checkout_update_order_meta($orderId)
    {
        require_once plugin_dir_path(__FILE__) . '/ListingManager.php';
        require_once plugin_dir_path(__FILE__) . '/helper/OrderHelper.php';

        $orderHelper = new ShipperHQ_OrderHelper($orderId);

        $settings = get_option('woocommerce_shipperhq_settings');
        $autoListingIsEnabled = array_key_exists('create_listing', $settings) && $settings['create_listing'] === 'AUTO';

        // SHQ18-2977 - Check if we even need to create a listing before wasting further effort
        if ($autoListingIsEnabled && $orderHelper->shippingMethodIsUship()) {
            $listingManager = new ShipperHQ_Listing_Manager();
            $listingManager->create_listing_for_order($orderId);
        }
    }

}