## 20.4.0 (2018-06-21)
Bring releases and versioning back in line


## 20.4.1 (2019-03-27)
SHQ18-1712 Dont send empty request to ShipperHQ


## 20.5.0 (2021-03-30)
RIV-443 Add placeorder support


## 20.6.0 (2021-12-21)
RIV-530 Support address for placeOrder request


## 20.7.0 (2022-05-13)
MNB-2430 M2.4.4 compatibility


## 20.7.1 (2023-03-22)
SHQ23-365 Move from Zend_Http to Laminas_Http


## 20.7.2 (2025-01-08)
SHQ23-4085 Update readme. SHQ23-4029 Add order date to place order


## 20.8.0 (2025-05-01)
SHQ23-4490 Add cartPrice optionally to createOrder mutation


## 20.9.0 (2025-05-07)
SHQ23-4531 Add response and allowed methods entities


## 20.9.1 (2025-05-07)
SHQ23-4531 Remove autoload registration file


## 20.9.2 (2025-06-25)
SHQ23-5236 Ensure selected options can never be null


## 20.10.0 (2025-06-26)
SHQ23-5319 Add return types and fix copyright and ensure php 8.4 compatibility


