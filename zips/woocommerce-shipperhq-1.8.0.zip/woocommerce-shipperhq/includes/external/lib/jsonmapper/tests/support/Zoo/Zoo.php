<?php
class Zoo
{
    /** @var Animal[] */
    public $animals;
}
