<?php

/*
Plugin Name: WooCommerce ShipperHQ
Plugin URI: http://www.shipperhq.com
Description: WooCommerce ShipperHQ Official Integration
Version: 1.6.4
Author: ShipperHQ
Text Domain: woocommerce-shipperhq
Domain Path: /languages
*/

if ( ! defined( 'ABSPATH' ) ) exit;

define('WC_SHIPPERHQ_ROOT_FILE', __FILE__ );

/**
 * Main ShipperHQ plugin class
 */
class WooCommerce_ShipperHQ {

    /**
     * Plugin version
     *
     * @var string
     */
    public $version = '1.8.0';

    /**
     * Singleton instance
     *
     * @var self|null
     */
    private static $instance = null;

    /**
     * Product data instance
     *
     * @var ShipperHQ_ProductData|null
     */
    private $product_data = null;

    /**
     * Order view instance
     *
     * @var ShipperHQ_OrderView|null
     */
    private $order_view = null;

    /**
     * Shipping instance
     *
     * @var ShipperHQ_Shipping|null
     */
    private $shipping = null;

    /**
     * Check if WooCommerce is active and initialize plugin
     */
    public function __construct()
    {
        if ( ! function_exists( 'is_plugin_active_for_network' ) ) {
            require_once( ABSPATH . '/wp-admin/includes/plugin.php' );
        }

        // is woocommerce active
        $active_plugins = apply_filters( 'active_plugins', get_option( 'active_plugins', array() ) );
        if ( !in_array( 'woocommerce/woocommerce.php', $active_plugins, true) ) {
            return;
        }

        $this->include_libs();
        $this->init_shipperhq();

        // Enqueue scripts
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 20 );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ), 20  );
    }

    /**
     * Include relevant classes
     *
     * @return void
     */
    private function include_libs()
    {
        $shq_dir = plugin_dir_path( __FILE__ ) ;
        require_once($shq_dir . '/includes/shipperhq/Shipping.php');
        require_once($shq_dir . '/includes/shipperhq/admin/ProductData.php');
        require_once($shq_dir . '/includes/shipperhq/admin/OrderView.php');
    }

    /**
     * Singleton
     *
     * @return WooCommerce_ShipperHQ
     */
    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize ShipperHQ components
     *
     * @return void
     */
    private function init_shipperhq()
    {
        $this->product_data = new ShipperHQ_ProductData();
        $this->order_view = new ShipperHQ_OrderView();
        $this->shipping = new ShipperHQ_Shipping();
    }

    /**
     * Enqueue scripts and styles for the plugin
     *
     * @return void
     */
    public function enqueue_scripts()
    {
        if ( is_admin() ) {
            // Admin scripts would go here
            // wp_enqueue_script( 'woocommerce-shipperhq-admin', plugins_url( '/assets/js/woocommerce-shipperhq-admin.js', __FILE__ ), array('jquery'), $this->version, true );
        } else {
            // Frontend scripts would go here
            // wp_enqueue_script( 'woocommerce-shipperhq', plugins_url( '/assets/js/woocommerce-shipperhq.js', __FILE__ ), array('jquery', 'wc-checkout'), $this->version, true );
        }
    }

    /**
     * Log messages to the debug log file
     *
     * @param string $message The message to log
     * @return void
     */
    public function log($message)
    {
        if ( 'yes' !== get_option( 'shipperhq_debug', 'yes' ) ) {
            return;
        }

        $log_file = plugin_dir_path( __FILE__ ) . '/log.txt';
        
        if ( is_writeable( $log_file ) || (!file_exists($log_file) && is_writeable(dirname($log_file))) ) {
            $log = fopen( $log_file, 'a+' );
            if ($log === false) {
                error_log( 'Could not open log file' );
                error_log( $message );
                return;
            }
            
            $message = '[' . date( 'd-m-Y H:i:s' ) . '] ' . $message . PHP_EOL;
            fwrite( $log, $message );
            fclose( $log );
        } else {
            error_log( 'log file not writable' );
            error_log( $message );
        }
    }
}

if ( ! function_exists( 'ShipperHQ' ) ) :

    /**
     * Returns the main instance of WooCommerce_ShipperHQ
     *
     * @return WooCommerce_ShipperHQ
     */
    function ShipperHQ()
    {
        return WooCommerce_ShipperHQ::get_instance();
    }

endif;

ShipperHQ();
