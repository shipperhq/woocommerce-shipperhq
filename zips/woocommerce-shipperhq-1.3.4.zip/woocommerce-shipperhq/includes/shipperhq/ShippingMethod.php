<?php
/* WooCommerce ShipperHQ
 *
 * Shipping method
 *
 * @author 		ShipperHQ
 * @category 	Shipping
 * @package 	woocommerce-shipperhq
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( class_exists( 'ShipperHQ_Shipping_Method' ) ) return; // Exit if class already exists


class ShipperHQ_Shipping_Method extends WC_Shipping_Method
{

    protected $_shipperHQHelper;
    protected $_wsHelper;
    /** @var bool Whether or not logging is enabled */
    public static $log_enabled = false;

    /** @var WC_Logger Logger instance */
    public static $log = false;


    public function __construct(){
        $this->id = 'shipperhq';
        $this->method_title = __( 'ShipperHQ', 'woocommerce' );
        $this->method_description = __( '
                    ShipperHQ Official Plugin - The most advanced eCommerce shipping management platform in the world. <br /><br />
                    For documentation and examples, please see the <a href="http://docs.shipperhq.com" target="_blank">ShipperHQ knowledge base</a>.<br /><br />
                    If you have questions about ShipperHQ or need support, visit <a href="http://www.ShipperHQ.com" target="_blank">http://www.ShipperHQ.com</a>.<br />
 				', 'woocommerce' );

        // Load the settings.
        $this->init_form_fields();

        $this->include_libs();
        // $this->validate_settings();

        $dateHelper = new \ShipperHQ\Lib\Helper\Date;
        $this->_shipperHQHelper = new \ShipperHQ\Lib\Rate\Helper($dateHelper);
        $this->_wsHelper = new ShipperHQ_RestHelper($this->get_option( 'sandbox_mode' ));

        // Define user set variables
        $this->enabled	= $this->get_option( 'enabled' );
        $this->title 		= $this->get_option( 'title' );
        $this->sanboxMode =  $this->get_option( 'title' );
        $this->debug = 'yes' === $this->get_option( 'debug', 'no' );
        self::$log_enabled    = $this->debug;

        add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
    }


    /**
     * Library functions
     *
     */
    private function include_libs()
    {
        $shq_dir = plugin_dir_path( __FILE__ );
        require_once($shq_dir . 'helper/Mapper.php');
        require_once($shq_dir . 'helper/RestHelper.php');
        require_once($shq_dir . '/../external/lib/library-shipper/src/Rate/ConfigSettings.php');
        require_once($shq_dir . '/../external/lib/library-shipper/src/Rate/Helper.php');
        require_once($shq_dir . '/../external/lib/library-shipper/src/Helper/Date.php');
        require_once($shq_dir . '/../external/lib/library-ws/src/Shared/Address.php');
        require_once($shq_dir . '/../external/lib/library-ws/src/Shared/Credentials.php');
        require_once($shq_dir . '/../external/lib/library-ws/src/Shared/SiteDetails.php');
        require_once($shq_dir . '/../external/lib/library-ws/src/Rate/Request/Checkout/Item.php');
        require_once($shq_dir . '/../external/lib/library-ws/src/Rate/Request/Checkout/Cart.php');
        require_once($shq_dir . '/../external/lib/library-ws/src/WebServiceRequestInterface.php');
        require_once($shq_dir . '/../external/lib/library-ws/src/AbstractWebServiceRequest.php');
        require_once($shq_dir . '/../external/lib/library-ws/src/Client/WebServiceClient.php');
        require_once($shq_dir . '/../external/lib/library-ws/src/Rate/Request/RateRequest.php');
        require_once($shq_dir . '/../external/lib/library-ws/src/Rate/Request/CustomerDetails.php');
    }


    public function calculate_shipping($package = array()){

        // lets call out to ShipperHQ
        $initVal = microtime(true);

        // create the request
        $shq_request = $this->create_request($package);

        if ($shq_request==null) {
            // couldn't create
            return;
        }

        // send the request
        $shq_results = $this->send_request($shq_request);

        // parse results
        $this->parse_shipping_results($shq_request, $shq_results);
        $elapsed = microtime(true) - $initVal;
        self::log('Shipperhq_Shipper Long lapse: ' .$elapsed);

    }

    /**
     * Create the request to send ShipperHQ
     *
     * @param $package
     * @return array|void
     */
    private function create_request($package)
    {
        // must have a country specified for us to get rates
        if ( '' == $package[ 'destination' ][ 'country' ] )
        {
            return;
        }

        $shq_api 		= new ShipperHQ_Mapper( );

        return $shq_api->create_request($package);
    }

    /**
     * Sends the JSON request
     *
     * @param $shq_request
     */
    private function send_request($shq_request)
    {
        $this->shipperRequest = $shq_request;
        $resultSet = null;
        $timeout = "30";

        if (!$resultSet) {
            $initVal =  microtime(true);
            $web_service_client = new \ShipperHQ\WS\Client\WebServiceClient();
            $resultSet = $web_service_client->sendAndReceiveWp($shq_request, $this->_wsHelper->getRateGatewayUrl(), $timeout);
            $elapsed = microtime(true) - $initVal;
            self::log('Shipperhq_Shipper Short lapse: '.$elapsed);

            if (!$resultSet['result']) {
//                $backupRates = $this->backupCarrier->getBackupCarrierRates($this->rawRequest, $this->getConfigData("backup_carrier"));
//                if ($backupRates) {
//                    return $backupRates;
//                }
                return;
            }

        }
        self::log('Rate request and result: ' );
        self::log($resultSet['debug']);

        return $resultSet['result'];
    }

    /**
     * Parse the results so can be output on frontend
     * @param $shq_request
     * @param $shipper_response
     */
    private function parse_shipping_results($shq_request, $shipper_response)
    {
        $debugRequest = $shq_request;

        $debugData = ['request' => $debugRequest, 'response' => $shipper_response];

        if (isset($shipper_response->carrierGroups)) {
            //SHQ16-2350
            $transactionId = $shipper_response->responseSummary->transactionId;
            $carrierRates = $this->processRatesResponse($shipper_response, $transactionId);
        } else {
            $carrierRates = [];
        }

        if (count($carrierRates) == 0) {
            self::log('WARNING: Shipper HQ did not return any carrier rates');
            self::log($debugData);
            return;
        }
        foreach ($carrierRates as $carrierRate) {
            if (isset($carrierRate['error'])) {
                self::log('Shipper HQ ' . $carrierRate['code'] . ' ' . $carrierRate['title'] .' returned error ' .$carrierRate['error']['internalErrorMessage']);
                continue;
            }
            if (!array_key_exists('rates', $carrierRate)) {
                self::log('WARNING: Shipper HQ did not return any rates for ' . $carrierRate['code'] . ' ' . $carrierRate['title']);
            } else {
                foreach ($carrierRate['rates'] as $rateDetails) {
                    $this->add_rate( array(
                        'id' 	=> $rateDetails['carrier_id']."_".$rateDetails['methodcode'],
                        'label' => $rateDetails['method_title'],
                        'cost' 	=> $rateDetails['price']
                    ));
                }
            }
        }
    }

    /*
    *
    * Build array of rates based on split or merged rates display
    */
    protected function processRatesResponse($shipperResponse, $transactionId)
    {
        $ratesArray = [];

        $configSetttings = $this->getConfigSettings();
        $splitCarrierGroupDetail = [];

        // if merged response lets take that
        if($shipperResponse->mergedRateResponse) {
            $mergedRatesArray = [];
            foreach($shipperResponse->mergedRateResponse->carrierRates as $carrierRate) {
                $mergedResultWithRates = $this->_shipperHQHelper->extractShipperHQMergedRates($carrierRate,
                    $splitCarrierGroupDetail, $configSetttings, $transactionId);
                $mergedRatesArray[] = $mergedResultWithRates;
            }
            $ratesArray = $mergedRatesArray;
        } else {

            $carrierGroups = $shipperResponse->carrierGroups;


            foreach ($carrierGroups as $carrierGroup) {
                $carrierGroupDetail = $this->_shipperHQHelper->extractCarriergroupDetail($carrierGroup, $transactionId, $configSetttings);

                //Pass off each carrier group to helper to decide best fit to process it.
                //Push result back into our array
                foreach ($carrierGroup->carrierRates as $carrierRate) {
                    $carrierResultWithRates = $this->_shipperHQHelper->extractShipperHQRates($carrierRate,
                        $carrierGroupDetail, $configSetttings, $splitCarrierGroupDetail);
                    $ratesArray[] = $carrierResultWithRates;
                }
            }
        }


        return $ratesArray;
    }


    protected function getLocaleInGlobals()
    {
        return 'en-US';
    }

    /**
     * Retrieve debug configuration
     * @return boolean
     */
    public function isTransactionIdEnabled()
    {
//        if (self::$showTransId == NULL) {
//            self::$showTransId = $this->getConfigValue('carriers/shipper/display_transaction');
//        }
        return false;

    }


    public function init_form_fields(){
        $this->form_fields = array(
            'enabled' => array(
                'title' 		=> __( 'Enable/Disable', 'woocommerce' ),
                'type' 			=> 'checkbox',
                'label' 		=> __( 'Enable ShipperHQ', 'woocommerce' ),
                'default' 		=> 'yes'
            ),
            'title' => array(
                'title' 		=> __( 'Main Shipping Carrier Title', 'woocommerce' ),
                'type' 			=> 'text',
                'description' 	=> __( 'Name of the main shipping carrier, also used for carrier title if no rates can be
                        found. This is updated dynamically from ShipperHQ', 'woocommerce' ),
                'default'		=> __( 'Shipping Rates', 'woocommerce' ),
            ),
            'api_key' => array(
                'title' 		=> __( 'API Key', 'woocommerce' ),
                'type' 			=> 'text',
                'description' 	=> __( 'Obtain from under Websites in the ShipperHQ Dashboard' ),
            ),
            'authentication_code' => array(
                'title' 		=> __( 'Authentication Code', 'woocommerce' ),
                'type' 			=> 'password',
                'description' 	=> __( 'Obtain from under Websites in the ShipperHQ Dashboard' ),
            ),
            'hide_notify' => array(
                'title' 		=> __( 'Carrier Notifications at Checkout', 'woocommerce' ),
                'label' 		=> __( 'Hide Notifications', 'woocommerce' ),
                'type' 			=> 'checkbox',
                'description' 	=> __( 'Carriers may include notifications when their live rates have been modified.' ),
                'default' 		=> 'no'
            ),
            'sandbox_mode' => array(
                'title' 		=> __( 'Use Sandbox', 'woocommerce' ),
                'type' 			=> 'checkbox',
                'label' 		=> __( 'Please leave Unchecked!', 'woocommerce' ),
                'default' 		=> 'no'
            ),
            'debug' => array(
                'title'       => __( 'Debug Log', 'woocommerce' ),
                'type'        => 'checkbox',
                'label'       => __( 'Enable logging', 'woocommerce' ),
                'default'     => 'no',
                'description' => sprintf( __( 'Log ShipperHQ shipping rate requests and debug information'))
            ),
        );
    }

    /**
     *
     *
     * @param array $package
     * @return bool
     */
    public function is_available( $package ){
        //TODO
        return parent::is_available($package);
    }

    /**
     * Logging method.
     * @param string $message
     */
    public static function log( $message ) {
        if ( self::$log_enabled ) {
            if ( empty( self::$log ) ) {
                self::$log = new WC_Logger();
            }
            self::$log->add( 'ShipperHQ', print_r($message, true) );
        }
    }


    /**
     * @return \ShipperHQ\Lib\Rate\ConfigSettings
     */
    protected function getConfigSettings()
    {
        $configSetttings = new \ShipperHQ\Lib\Rate\ConfigSettings($this->get_option('hide_notify'),
            $this->isTransactionIdEnabled(),$this->getLocaleInGlobals(), "shipperhq", $this->get_option('title'),
            wc_timezone_string());
        $configSetttings->hideNotifications = $this->get_option('hide_notify');
        $configSetttings->transactionIdEnabled = $this->isTransactionIdEnabled();
        $configSetttings->locale = $this->getLocaleInGlobals();
        return $configSetttings;
    }

}